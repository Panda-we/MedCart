import React from 'react';
import { motion } from 'framer-motion';
import WaterWaveBackground from './WaterWaveBackground';
import { Card, CardContent } from '@/components/ui/card';

interface WaterWaveSectionProps {
  title?: string;
  subtitle?: string;
  children?: React.ReactNode;
  className?: string;
}

const WaterWaveSection: React.FC<WaterWaveSectionProps> = ({
  title,
  subtitle,
  children,
  className = ''
}) => {
  return (
    <WaterWaveBackground className={`py-20 ${className}`} showImages={false} data-id="q64wo8jwg" data-path="src/components/WaterWaveSection.tsx">
      <div className="container mx-auto px-4" data-id="pz0c4l16u" data-path="src/components/WaterWaveSection.tsx">
        {(title || subtitle) &&
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16" data-id="8vembzvhi" data-path="src/components/WaterWaveSection.tsx">

            {title &&
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-4 drop-shadow-lg" data-id="rhcv84d3j" data-path="src/components/WaterWaveSection.tsx">
                {title}
              </h2>
          }
            {subtitle &&
          <p className="text-xl md:text-2xl text-blue-100 max-w-3xl mx-auto leading-relaxed" data-id="hjuswgtze" data-path="src/components/WaterWaveSection.tsx">
                {subtitle}
              </p>
          }
          </motion.div>
        }
        
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          viewport={{ once: true }} data-id="0wqslwjx3" data-path="src/components/WaterWaveSection.tsx">

          {children}
        </motion.div>
      </div>
    </WaterWaveBackground>);

};

// Example usage component with water theme content
export const WaterThemeShowcase: React.FC = () => {
  const oceanFeatures = [
  {
    title: "Deep Sea Exploration",
    description: "Dive into the mysteries of the ocean depths",
    image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400&h=300&fit=crop&crop=center"
  },
  {
    title: "Marine Ecosystem",
    description: "Discover the vibrant life beneath the waves",
    image: "https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=400&h=300&fit=crop&crop=center"
  },
  {
    title: "Coral Reefs",
    description: "Explore the colorful underwater cities",
    image: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=400&h=300&fit=crop&crop=center"
  }];


  return (
    <WaterWaveSection
      title="Ocean Wonders"
      subtitle="Immerse yourself in the beauty and mystery of marine life" data-id="knw95la6x" data-path="src/components/WaterWaveSection.tsx">

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" data-id="kkmz0m5dh" data-path="src/components/WaterWaveSection.tsx">
        {oceanFeatures.map((feature, index) =>
        <motion.div
          key={index}
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: index * 0.2 }}
          viewport={{ once: true }}
          whileHover={{ y: -10, scale: 1.02 }}
          className="group" data-id="eew55sarw" data-path="src/components/WaterWaveSection.tsx">

            <Card className="bg-white/10 backdrop-blur-md border-white/20 hover:bg-white/20 transition-all duration-300 overflow-hidden" data-id="ds7m8s5yz" data-path="src/components/WaterWaveSection.tsx">
              <div className="relative h-48 overflow-hidden" data-id="5vnutug89" data-path="src/components/WaterWaveSection.tsx">
                <img
                src={feature.image}
                alt={feature.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" data-id="9mekd0q4r" data-path="src/components/WaterWaveSection.tsx" />

                <div className="absolute inset-0 bg-gradient-to-t from-blue-900/60 to-transparent" data-id="hkmyk3cn4" data-path="src/components/WaterWaveSection.tsx" />
              </div>
              <CardContent className="p-6" data-id="cqjfjc6xl" data-path="src/components/WaterWaveSection.tsx">
                <h3 className="text-xl font-bold text-white mb-3 group-hover:text-cyan-200 transition-colors" data-id="snmo5bzsf" data-path="src/components/WaterWaveSection.tsx">
                  {feature.title}
                </h3>
                <p className="text-blue-100 leading-relaxed" data-id="ea2n86bxx" data-path="src/components/WaterWaveSection.tsx">
                  {feature.description}
                </p>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </div>
    </WaterWaveSection>);

};

export default WaterWaveSection;