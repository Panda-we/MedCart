import React, { useEffect, useState } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ArrowRight, Play, Star, Award } from 'lucide-react';

const ParallaxSection: React.FC = () => {
  const [scrollY, setScrollY] = useState(0);
  const { scrollYProgress } = useScroll();

  const y1 = useTransform(scrollYProgress, [0, 1], [0, -100]);
  const y2 = useTransform(scrollYProgress, [0, 1], [0, -200]);
  const y3 = useTransform(scrollYProgress, [0, 1], [0, -50]);

  useEffect(() => {
    const handleScroll = () => setScrollY(window.scrollY);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section className="relative min-h-screen overflow-hidden bg-black" data-id="2lkpkkub0" data-path="src/components/ParallaxSection.tsx">
      {/* Background Layers */}
      <div className="absolute inset-0" data-id="nkbk502w0" data-path="src/components/ParallaxSection.tsx">
        <motion.div
          style={{ y: y2 }}
          className="absolute inset-0 bg-gradient-to-br from-emerald-900/20 to-teal-900/20" data-id="06ooihqu1" data-path="src/components/ParallaxSection.tsx" />

        <motion.div
          style={{ y: y1 }}
          className="absolute top-0 left-0 w-full h-full bg-cover bg-center opacity-30"
          style={{
            backgroundImage: `url("https://images.unsplash.com/photo-1559757175-5154004e9d90?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&q=80")`
          }} data-id="zy5k673ec" data-path="src/components/ParallaxSection.tsx" />

      </div>

      {/* Floating Elements */}
      <motion.div
        style={{ y: y3 }}
        className="absolute top-20 left-10 w-20 h-20 bg-emerald-400/10 rounded-full blur-xl"
        animate={{
          scale: [1, 1.2, 1],
          opacity: [0.3, 0.6, 0.3]
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          repeatType: "reverse"
        }} data-id="j6ir1oen6" data-path="src/components/ParallaxSection.tsx" />

      
      <motion.div
        style={{ y: y1 }}
        className="absolute top-40 right-20 w-32 h-32 bg-blue-400/10 rounded-full blur-2xl"
        animate={{
          scale: [1.2, 1, 1.2],
          opacity: [0.2, 0.5, 0.2]
        }}
        transition={{
          duration: 6,
          repeat: Infinity,
          repeatType: "reverse"
        }} data-id="q32c7wf0t" data-path="src/components/ParallaxSection.tsx" />


      {/* Content */}
      <div className="relative z-10 min-h-screen flex items-center" data-id="2o20mw3sb" data-path="src/components/ParallaxSection.tsx">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full" data-id="ga1kelf9q" data-path="src/components/ParallaxSection.tsx">
          <div className="grid lg:grid-cols-2 gap-12 items-center" data-id="totl9lgpk" data-path="src/components/ParallaxSection.tsx">
            {/* Left Column - Text Content */}
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }} data-id="9mseou4w5" data-path="src/components/ParallaxSection.tsx">

              <motion.div
                className="mb-6"
                animate={{ y: [0, -10, 0] }}
                transition={{ duration: 3, repeat: Infinity }} data-id="ds2opvmcb" data-path="src/components/ParallaxSection.tsx">

                <div className="inline-flex items-center space-x-2 bg-emerald-400/10 rounded-full px-4 py-2 border border-emerald-400/20" data-id="whe230wiz" data-path="src/components/ParallaxSection.tsx">
                  <Award className="h-4 w-4 text-emerald-400" data-id="49adzhv1v" data-path="src/components/ParallaxSection.tsx" />
                  <span className="text-emerald-400 font-semibold text-sm" data-id="571tsf7aj" data-path="src/components/ParallaxSection.tsx">
                    Premium Healthcare Experience
                  </span>
                </div>
              </motion.div>

              <h2 className="text-5xl md:text-6xl font-bold text-white mb-6 leading-tight" data-id="16h0x900y" data-path="src/components/ParallaxSection.tsx">
                Advanced
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400" data-id="hgmilf4gf" data-path="src/components/ParallaxSection.tsx">
                  {" "}Medical{" "}
                </span>
                Solutions
              </h2>

              <p className="text-xl text-gray-300 mb-8 leading-relaxed" data-id="45a75d6wx" data-path="src/components/ParallaxSection.tsx">
                Experience the future of healthcare with our cutting-edge medical devices and 
                innovative solutions. Trusted by healthcare professionals worldwide for 
                superior quality and reliability.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-8" data-id="omipm1irw" data-path="src/components/ParallaxSection.tsx">
                <Button
                  size="lg"
                  className="bg-emerald-400 hover:bg-emerald-500 text-black font-semibold px-8 py-4 rounded-full group" data-id="gmn37cs15" data-path="src/components/ParallaxSection.tsx">

                  Explore Products
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" data-id="elr0ninwn" data-path="src/components/ParallaxSection.tsx" />
                </Button>
                
                <Button
                  variant="outline"
                  size="lg"
                  className="border-emerald-400 text-emerald-400 hover:bg-emerald-400 hover:text-black px-8 py-4 rounded-full group" data-id="e7bnb26ae" data-path="src/components/ParallaxSection.tsx">

                  <Play className="mr-2 h-4 w-4 group-hover:scale-110 transition-transform" data-id="2qlvr24lw" data-path="src/components/ParallaxSection.tsx" />
                  Watch Demo
                </Button>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6" data-id="or2bul4d4" data-path="src/components/ParallaxSection.tsx">
                {[
                { number: "50K+", label: "Healthcare Professionals" },
                { number: "500+", label: "Medical Institutions" },
                { number: "99.9%", label: "Customer Satisfaction" }].
                map((stat, index) =>
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.2 + index * 0.1, duration: 0.6 }}
                  className="text-center" data-id="cubz75k93" data-path="src/components/ParallaxSection.tsx">

                    <div className="text-2xl font-bold text-emerald-400 mb-1" data-id="ig1wjodw8" data-path="src/components/ParallaxSection.tsx">
                      {stat.number}
                    </div>
                    <div className="text-sm text-gray-400" data-id="i6fb9fchb" data-path="src/components/ParallaxSection.tsx">
                      {stat.label}
                    </div>
                  </motion.div>
                )}
              </div>
            </motion.div>

            {/* Right Column - Visual Content */}
            <motion.div
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
              className="relative" data-id="yfmf6n9it" data-path="src/components/ParallaxSection.tsx">

              <motion.div
                style={{ y: y3 }}
                className="relative" data-id="21sccpnp7" data-path="src/components/ParallaxSection.tsx">

                {/* Main Image */}
                <div className="relative rounded-2xl overflow-hidden" data-id="p31wh2s0k" data-path="src/components/ParallaxSection.tsx">
                  <img
                    src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80"
                    alt="Medical Technology"
                    className="w-full h-96 object-cover" data-id="x5egwbe1b" data-path="src/components/ParallaxSection.tsx" />

                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" data-id="bnhrzt27b" data-path="src/components/ParallaxSection.tsx" />
                </div>

                {/* Floating Cards */}
                <motion.div
                  className="absolute -top-6 -left-6 bg-gray-800/90 backdrop-blur-sm rounded-xl p-4 border border-gray-700"
                  animate={{
                    y: [0, -10, 0],
                    rotate: [-2, 2, -2]
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    repeatType: "reverse"
                  }} data-id="pj9yjjlnh" data-path="src/components/ParallaxSection.tsx">

                  <div className="flex items-center space-x-2" data-id="vf2hykc1l" data-path="src/components/ParallaxSection.tsx">
                    <Star className="h-5 w-5 text-yellow-400 fill-current" data-id="so754aycu" data-path="src/components/ParallaxSection.tsx" />
                    <span className="text-white font-semibold" data-id="59senq811" data-path="src/components/ParallaxSection.tsx">4.9/5</span>
                  </div>
                  <div className="text-sm text-gray-400" data-id="8new60oa5" data-path="src/components/ParallaxSection.tsx">Customer Rating</div>
                </motion.div>

                <motion.div
                  className="absolute -bottom-6 -right-6 bg-emerald-400/90 backdrop-blur-sm rounded-xl p-4"
                  animate={{
                    y: [0, 10, 0],
                    rotate: [2, -2, 2]
                  }}
                  transition={{
                    duration: 5,
                    repeat: Infinity,
                    repeatType: "reverse"
                  }} data-id="l6r590l09" data-path="src/components/ParallaxSection.tsx">

                  <div className="text-black font-bold text-lg" data-id="3zjpkjqud" data-path="src/components/ParallaxSection.tsx">99.9%</div>
                  <div className="text-black/70 text-sm" data-id="kawm08kno" data-path="src/components/ParallaxSection.tsx">Accuracy Rate</div>
                </motion.div>
              </motion.div>

              {/* Decorative Elements */}
              <motion.div
                className="absolute top-10 right-10 w-4 h-4 bg-emerald-400 rounded-full"
                animate={{
                  scale: [1, 1.5, 1],
                  opacity: [0.5, 1, 0.5]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  repeatType: "reverse"
                }} data-id="s1srwsv5o" data-path="src/components/ParallaxSection.tsx" />

              
              <motion.div
                className="absolute bottom-20 left-10 w-6 h-6 border-2 border-blue-400 rounded-full"
                animate={{
                  rotate: 360
                }}
                transition={{
                  duration: 10,
                  repeat: Infinity,
                  ease: "linear"
                }} data-id="exn5japjl" data-path="src/components/ParallaxSection.tsx" />

            </motion.div>
          </div>
        </div>
      </div>

      {/* Bottom Gradient Overlay */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-black to-transparent pointer-events-none" data-id="inr1cm21a" data-path="src/components/ParallaxSection.tsx" />
    </section>);

};

export default ParallaxSection;