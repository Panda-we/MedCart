import React, { useState, useEffect, useRef } from 'react';
import { motion, useMotionValue, useSpring } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Play, Star } from 'lucide-react';

const HeroCarousel = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const heroRef = useRef<HTMLDivElement>(null);

  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const springX = useSpring(mouseX, { stiffness: 150, damping: 15 });
  const springY = useSpring(mouseY, { stiffness: 150, damping: 15 });

  const slides = [
  {
    title: "Revolutionary Design Platform",
    subtitle: "Create stunning websites with AI-powered tools",
    description: "Experience the future of web design with our cutting-edge platform that combines creativity with intelligent automation.",
    image: "https://images.unsplash.com/photo-1557804506-669a67965ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    gradient: "from-purple-600 via-pink-600 to-blue-600"
  },
  {
    title: "Advanced Analytics Dashboard",
    subtitle: "Data-driven insights for better decisions",
    description: "Transform your business with comprehensive analytics and real-time reporting that drives growth and optimization.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    gradient: "from-blue-600 via-teal-600 to-green-600"
  },
  {
    title: "Seamless Integration",
    subtitle: "Connect all your favorite tools",
    description: "Streamline your workflow with powerful integrations that bring all your essential tools together in one platform.",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
    gradient: "from-orange-600 via-red-600 to-pink-600"
  }];


  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 6000);
    return () => clearInterval(timer);
  }, [slides.length]);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (heroRef.current) {
        const rect = heroRef.current.getBoundingClientRect();
        const x = (e.clientX - rect.left - rect.width / 2) / rect.width;
        const y = (e.clientY - rect.top - rect.height / 2) / rect.height;

        mouseX.set(x * 50);
        mouseY.set(y * 50);

        setMousePosition({ x: x * 20, y: y * 20 });
      }
    };

    const heroElement = heroRef.current;
    if (heroElement) {
      heroElement.addEventListener('mousemove', handleMouseMove);
      return () => heroElement.removeEventListener('mousemove', handleMouseMove);
    }
  }, [mouseX, mouseY]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % slides.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);
  };

  return (
    <section ref={heroRef} className="relative min-h-screen flex items-center justify-center overflow-hidden" data-id="oulwfw572" data-path="src/components/HeroCarousel.tsx">
      {/* Animated Background Gradient */}
      <motion.div
        className={`absolute inset-0 bg-gradient-to-br ${slides[currentSlide].gradient} opacity-90`}
        style={{
          x: springX,
          y: springY
        }}
        animate={{
          backgroundPosition: ['0% 0%', '100% 100%']
        }}
        transition={{
          duration: 20,
          repeat: Infinity,
          repeatType: 'reverse'
        }} data-id="3hiy2sluz" data-path="src/components/HeroCarousel.tsx" />


      {/* Parallax Background Pattern */}
      <motion.div
        className="absolute inset-0 opacity-10"
        style={{
          x: mousePosition.x * 0.5,
          y: mousePosition.y * 0.5
        }} data-id="mycbhvoyo" data-path="src/components/HeroCarousel.tsx">

        <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[length:50px_50px]" data-id="0q16svsam" data-path="src/components/HeroCarousel.tsx" />
      </motion.div>

      {/* Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-id="btw7xjz8o" data-path="src/components/HeroCarousel.tsx">
        <div className="grid lg:grid-cols-2 gap-12 items-center" data-id="7i8hhmlet" data-path="src/components/HeroCarousel.tsx">
          {/* Text Content with Parallax */}
          <motion.div
            className="text-center lg:text-left"
            style={{
              x: mousePosition.x * -0.3,
              y: mousePosition.y * -0.3
            }} data-id="6gdoqinop" data-path="src/components/HeroCarousel.tsx">

            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -50 }}
              transition={{ duration: 0.8 }} data-id="gnbpxrftn" data-path="src/components/HeroCarousel.tsx">

              <motion.h1
                className="text-5xl md:text-7xl font-bold text-white mb-6 leading-tight"
                style={{
                  x: mousePosition.x * 0.2,
                  y: mousePosition.y * 0.2
                }} data-id="6xuihqp9p" data-path="src/components/HeroCarousel.tsx">

                {slides[currentSlide].title}
              </motion.h1>
              
              <motion.p
                className="text-xl md:text-2xl text-white/90 mb-4 font-light"
                style={{
                  x: mousePosition.x * 0.1,
                  y: mousePosition.y * 0.1
                }} data-id="1kuske6rt" data-path="src/components/HeroCarousel.tsx">

                {slides[currentSlide].subtitle}
              </motion.p>
              
              <motion.p
                className="text-lg text-white/80 mb-8 max-w-lg mx-auto lg:mx-0"
                style={{
                  x: mousePosition.x * 0.05,
                  y: mousePosition.y * 0.05
                }} data-id="ouhpeuofk" data-path="src/components/HeroCarousel.tsx">

                {slides[currentSlide].description}
              </motion.p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start" data-id="i4wx8aa08" data-path="src/components/HeroCarousel.tsx">
                <Button size="lg" className="bg-white text-gray-900 hover:bg-gray-100 group" data-id="3apzrpyq4" data-path="src/components/HeroCarousel.tsx">
                  <Play className="w-5 h-5 mr-2 group-hover:scale-110 transition-transform" data-id="k8kpzyc13" data-path="src/components/HeroCarousel.tsx" />
                  Get Started
                </Button>
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-gray-900" data-id="hqxhx8acx" data-path="src/components/HeroCarousel.tsx">
                  Watch Demo
                </Button>
              </div>

              {/* Stats */}
              <motion.div
                className="flex items-center justify-center lg:justify-start gap-8 mt-12"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.6 }} data-id="83wmueo8k" data-path="src/components/HeroCarousel.tsx">

                <div className="text-center" data-id="1u63do5tw" data-path="src/components/HeroCarousel.tsx">
                  <div className="flex items-center mb-1" data-id="m17ll9ale" data-path="src/components/HeroCarousel.tsx">
                    {[...Array(5)].map((_, i) =>
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" data-id="areyo3dwi" data-path="src/components/HeroCarousel.tsx" />
                    )}
                  </div>
                  <p className="text-white/80 text-sm" data-id="xh29x91vo" data-path="src/components/HeroCarousel.tsx">5.0 Rating</p>
                </div>
                <div className="text-center" data-id="ydyntz3b2" data-path="src/components/HeroCarousel.tsx">
                  <p className="text-2xl font-bold text-white" data-id="rcqtec9p5" data-path="src/components/HeroCarousel.tsx">50K+</p>
                  <p className="text-white/80 text-sm" data-id="v7pdqhrdt" data-path="src/components/HeroCarousel.tsx">Happy Users</p>
                </div>
                <div className="text-center" data-id="a3l14p9g9" data-path="src/components/HeroCarousel.tsx">
                  <p className="text-2xl font-bold text-white" data-id="fvh2iudad" data-path="src/components/HeroCarousel.tsx">99.9%</p>
                  <p className="text-white/80 text-sm" data-id="wvm53ixc8" data-path="src/components/HeroCarousel.tsx">Uptime</p>
                </div>
              </motion.div>
            </motion.div>
          </motion.div>

          {/* Image with Parallax */}
          <motion.div
            className="relative"
            style={{
              x: mousePosition.x * 0.3,
              y: mousePosition.y * 0.3
            }} data-id="zxmp7svsk" data-path="src/components/HeroCarousel.tsx">

            <motion.div
              key={currentSlide}
              initial={{ opacity: 0, scale: 0.9, rotateY: 15 }}
              animate={{ opacity: 1, scale: 1, rotateY: 0 }}
              exit={{ opacity: 0, scale: 0.9, rotateY: -15 }}
              transition={{ duration: 0.8 }}
              className="relative group" data-id="r4cvxrfgs" data-path="src/components/HeroCarousel.tsx">

              <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent rounded-2xl" data-id="2pe5zwual" data-path="src/components/HeroCarousel.tsx" />
              <img
                src={slides[currentSlide].image}
                alt={slides[currentSlide].title}
                className="w-full h-[500px] object-cover rounded-2xl shadow-2xl group-hover:scale-105 transition-transform duration-700" data-id="k373l9lie" data-path="src/components/HeroCarousel.tsx" />

              <div className="absolute inset-0 bg-black/10 rounded-2xl" data-id="rj84kr0b9" data-path="src/components/HeroCarousel.tsx" />
            </motion.div>
          </motion.div>
        </div>
      </div>

      {/* Navigation */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex items-center gap-4" data-id="xvwb3ussc" data-path="src/components/HeroCarousel.tsx">
        <Button
          variant="outline"
          size="icon"
          onClick={prevSlide}
          className="border-white text-white hover:bg-white hover:text-gray-900" data-id="49uqxf63f" data-path="src/components/HeroCarousel.tsx">

          <ChevronLeft className="w-5 h-5" data-id="i62nyrp6w" data-path="src/components/HeroCarousel.tsx" />
        </Button>
        
        <div className="flex gap-2" data-id="y3ikkvu00" data-path="src/components/HeroCarousel.tsx">
          {slides.map((_, index) =>
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
            index === currentSlide ?
            'bg-white scale-125' :
            'bg-white/50 hover:bg-white/80'}`
            } data-id="xdlucgo1i" data-path="src/components/HeroCarousel.tsx" />

          )}
        </div>
        
        <Button
          variant="outline"
          size="icon"
          onClick={nextSlide}
          className="border-white text-white hover:bg-white hover:text-gray-900" data-id="ou6az7vvv" data-path="src/components/HeroCarousel.tsx">

          <ChevronRight className="w-5 h-5" data-id="er8hd3b0c" data-path="src/components/HeroCarousel.tsx" />
        </Button>
      </div>

      {/* Floating Elements */}
      <motion.div
        className="absolute top-20 left-20 w-20 h-20 rounded-full bg-white/10 backdrop-blur-sm"
        animate={{
          y: [0, -20, 0],
          rotate: [0, 180, 360]
        }}
        transition={{
          duration: 8,
          repeat: Infinity
        }}
        style={{
          x: mousePosition.x * -0.5,
          y: mousePosition.y * -0.5
        }} data-id="538z9ak64" data-path="src/components/HeroCarousel.tsx" />

      
      <motion.div
        className="absolute bottom-32 right-20 w-16 h-16 rounded-full bg-white/10 backdrop-blur-sm"
        animate={{
          y: [0, 20, 0],
          rotate: [360, 180, 0]
        }}
        transition={{
          duration: 6,
          repeat: Infinity
        }}
        style={{
          x: mousePosition.x * 0.5,
          y: mousePosition.y * 0.5
        }} data-id="ltuyokrgq" data-path="src/components/HeroCarousel.tsx" />

    </section>);

};

export default HeroCarousel;