import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Zap,
  Shield,
  Palette,
  Code,
  Smartphone,
  Globe,
  BarChart3,
  Users,
  Lock } from
'lucide-react';
import TiltCard from './TiltCard';

const FeatureCards = () => {
  const features = [
  {
    icon: Zap,
    title: "Lightning Fast",
    description: "Experience blazing speed like a lightning bolt cutting through water. Our optimized performance delivers sub-second load times.",
    gradient: "from-yellow-400 to-orange-500",
    waterColor: "from-blue-400 to-cyan-500",
    delay: 0.1
  },
  {
    icon: Shield,
    title: "Deep Sea Security",
    description: "Protected like treasures in the ocean depths. Bank-level security with end-to-end encryption flows through every interaction.",
    gradient: "from-green-400 to-emerald-500",
    waterColor: "from-teal-400 to-blue-500",
    delay: 0.2
  },
  {
    icon: Palette,
    title: "Fluid Design",
    description: "Design that flows like water, adapting seamlessly. Stunning interfaces crafted with the fluidity of ocean waves.",
    gradient: "from-purple-400 to-pink-500",
    waterColor: "from-indigo-400 to-purple-500",
    delay: 0.3
  },
  {
    icon: Code,
    title: "Stream Development",
    description: "Development that flows effortlessly. Clean APIs and comprehensive documentation make integration as smooth as a gentle stream.",
    gradient: "from-blue-400 to-indigo-500",
    waterColor: "from-blue-500 to-indigo-600",
    delay: 0.4
  },
  {
    icon: Smartphone,
    title: "Ocean of Devices",
    description: "Responsive across the vast ocean of devices. Perfect adaptation from smartphones to desktops, like water taking any shape.",
    gradient: "from-teal-400 to-cyan-500",
    waterColor: "from-cyan-400 to-blue-500",
    delay: 0.5
  },
  {
    icon: Globe,
    title: "Global Currents",
    description: "Flowing across global networks like ocean currents. Built to handle millions worldwide with seamless distribution.",
    gradient: "from-red-400 to-rose-500",
    waterColor: "from-blue-400 to-indigo-500",
    delay: 0.6
  },
  {
    icon: BarChart3,
    title: "Deep Analytics",
    description: "Dive deep into your data ocean. Real-time analytics flow through custom dashboards revealing hidden insights.",
    gradient: "from-amber-400 to-yellow-500",
    waterColor: "from-blue-500 to-teal-500",
    delay: 0.7
  },
  {
    icon: Users,
    title: "Team Waves",
    description: "Collaboration flows like synchronized waves. Real-time editing and team management create perfect harmony.",
    gradient: "from-violet-400 to-purple-500",
    waterColor: "from-indigo-400 to-blue-500",
    delay: 0.8
  },
  {
    icon: Lock,
    title: "Privacy Depths",
    description: "Your privacy protected in the secure depths. Transparent policies give you complete control over your data ocean.",
    gradient: "from-slate-400 to-gray-500",
    waterColor: "from-slate-500 to-blue-600",
    delay: 0.9
  }];


  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: {
      opacity: 0,
      y: 50,
      scale: 0.9
    },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <section className="py-24 bg-gradient-to-br from-gray-50 to-white relative overflow-hidden" data-id="vlbnd01rr" data-path="src/components/FeatureCards.tsx">
      {/* Background water pattern */}
      <div className="absolute inset-0 opacity-5" data-id="lafkvmelm" data-path="src/components/FeatureCards.tsx">
        <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none" data-id="fmn6g9sex" data-path="src/components/FeatureCards.tsx">
          <path d="M0,50 Q25,45 50,50 T100,50 L100,100 L0,100 Z" fill="url(#water-gradient)" data-id="n71goav3q" data-path="src/components/FeatureCards.tsx" />
          <defs data-id="fkbf5skm1" data-path="src/components/FeatureCards.tsx">
            <linearGradient id="water-gradient" x1="0%" y1="0%" x2="100%" y2="100%" data-id="xqi53r9gk" data-path="src/components/FeatureCards.tsx">
              <stop offset="0%" stopColor="#3b82f6" data-id="enwf89cb2" data-path="src/components/FeatureCards.tsx" />
              <stop offset="100%" stopColor="#1e40af" data-id="ltkfpipph" data-path="src/components/FeatureCards.tsx" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10" data-id="w6sw2mjnf" data-path="src/components/FeatureCards.tsx">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16" data-id="nu277x6s4" data-path="src/components/FeatureCards.tsx">
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6" data-id="zi3s6j7wk" data-path="src/components/FeatureCards.tsx">
            Powerful Features for
            <span className="water-gradient-text block mt-2" data-id="jii3n5iww" data-path="src/components/FeatureCards.tsx">Ocean-Deep Innovation</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-id="tzo0b2zyi" data-path="src/components/FeatureCards.tsx">
            Dive into a sea of possibilities. Our comprehensive platform flows with 
            cutting-edge tools designed for the currents of tomorrow.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" data-id="7y207s950" data-path="src/components/FeatureCards.tsx">
          {features.map((feature, index) =>
          <motion.div
            key={index}
            variants={itemVariants}
            whileHover={{
              y: -10,
              transition: { duration: 0.3 }
            }} data-id="nqa4kxnwu" data-path="src/components/FeatureCards.tsx">
              <TiltCard maxTilt={8} scale={1.02} className="h-full" data-id="wssxb3tou" data-path="src/components/FeatureCards.tsx">
                <Card className="h-full border-0 shadow-lg hover:shadow-2xl transition-all duration-500 bg-white/80 backdrop-blur-sm group overflow-hidden water-card ripple-effect" data-id="y98v7kj61" data-path="src/components/FeatureCards.tsx">
                  {/* Water ripple background */}
                  <div className={`absolute inset-0 bg-gradient-to-br ${feature.waterColor} opacity-0 group-hover:opacity-10 transition-all duration-700`} data-id="4abwzrz7i" data-path="src/components/FeatureCards.tsx" />
                  
                  {/* Floating water droplets */}
                  <div className="absolute inset-0 pointer-events-none overflow-hidden" data-id="nlwqe71b4" data-path="src/components/FeatureCards.tsx">
                    {[...Array(3)].map((_, i) =>
                  <motion.div
                    key={i}
                    className="absolute w-2 h-2 rounded-full bg-blue-400 opacity-0 group-hover:opacity-30"
                    style={{
                      left: `${20 + i * 30}%`,
                      top: `${20 + i * 20}%`
                    }}
                    animate={{
                      y: [0, -10, 0],
                      scale: [0.8, 1.2, 0.8],
                      opacity: [0, 0.3, 0]
                    }}
                    transition={{
                      duration: 2 + i * 0.5,
                      repeat: Infinity,
                      delay: i * 0.3
                    }} data-id="4g8ok4dli" data-path="src/components/FeatureCards.tsx" />

                  )}
                  </div>

                  {/* Wave effect on hover */}
                  <motion.div
                  className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-500 opacity-0 group-hover:opacity-100"
                  initial={{ scaleX: 0 }}
                  whileInView={{ scaleX: 1 }}
                  viewport={{ once: true }}
                  transition={{
                    delay: feature.delay,
                    duration: 1.2,
                    ease: "easeInOut"
                  }} data-id="1g3gotqw5" data-path="src/components/FeatureCards.tsx" />

                  
                  <CardHeader className="relative z-10" data-id="g7rqle3il" data-path="src/components/FeatureCards.tsx">
                    <motion.div
                    whileHover={{
                      scale: 1.1,
                      rotate: 10
                    }}
                    transition={{ duration: 0.3 }}
                    className={`w-14 h-14 rounded-xl bg-gradient-to-br ${feature.gradient} p-3 mb-4 shadow-lg group-hover:shadow-xl`} data-id="htxpjjepi" data-path="src/components/FeatureCards.tsx">
                      <feature.icon className="w-full h-full text-white" data-id="xfzd2j750" data-path="src/components/FeatureCards.tsx" />
                    </motion.div>
                    
                    <CardTitle className="text-xl font-bold text-gray-900 group-hover:text-blue-900 transition-colors" data-id="3afm7z5gm" data-path="src/components/FeatureCards.tsx">
                      {feature.title}
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent className="relative z-10" data-id="iauxd7x89" data-path="src/components/FeatureCards.tsx">
                    <CardDescription className="text-gray-600 leading-relaxed group-hover:text-gray-700 transition-colors" data-id="znzdps0qr" data-path="src/components/FeatureCards.tsx">
                      {feature.description}
                    </CardDescription>
                    
                    {/* Animated progress line */}
                    <motion.div
                    className={`h-1 bg-gradient-to-r ${feature.waterColor} mt-6 rounded-full relative overflow-hidden`}
                    initial={{ width: 0 }}
                    whileInView={{ width: '100%' }}
                    viewport={{ once: true }}
                    transition={{
                      delay: feature.delay,
                      duration: 0.8,
                      ease: "easeOut"
                    }} data-id="d49cqqnqi" data-path="src/components/FeatureCards.tsx">
                      {/* Wave shimmer effect */}
                      <motion.div
                      className="absolute inset-0 bg-gradient-to-r from-transparent via-white to-transparent opacity-30"
                      animate={{
                        x: ['-100%', '100%']
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity,
                        ease: "linear"
                      }} data-id="7gyto9s9w" data-path="src/components/FeatureCards.tsx" />

                    </motion.div>
                  </CardContent>

                  {/* Floating water particles */}
                  <motion.div
                  className="absolute top-4 right-4 w-3 h-3 rounded-full bg-gradient-to-r from-blue-400 to-cyan-400 opacity-0 group-hover:opacity-60"
                  animate={{
                    y: [0, -15, 0],
                    scale: [0.8, 1.2, 0.8],
                    opacity: [0.2, 0.6, 0.2]
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    delay: Math.random() * 2
                  }} data-id="uqxr6jpmo" data-path="src/components/FeatureCards.tsx" />

                  
                  <motion.div
                  className="absolute bottom-8 left-6 w-2 h-2 rounded-full bg-gradient-to-r from-teal-400 to-blue-400 opacity-0 group-hover:opacity-50"
                  animate={{
                    x: [0, 15, 0],
                    rotate: [0, 360, 0],
                    opacity: [0.2, 0.5, 0.2]
                  }}
                  transition={{
                    duration: 4,
                    repeat: Infinity,
                    delay: Math.random() * 2
                  }} data-id="j9zdp01yi" data-path="src/components/FeatureCards.tsx" />


                  {/* Ocean depth glow */}
                  <div className="absolute inset-0 rounded-xl bg-gradient-to-t from-blue-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" data-id="navoen9kr" data-path="src/components/FeatureCards.tsx" />
                </Card>
              </TiltCard>
            </motion.div>
          )}
        </motion.div>

        {/* Call to Action with water theme */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="text-center mt-16" data-id="mp5ed19e9" data-path="src/components/FeatureCards.tsx">
          <motion.button
            whileHover={{
              scale: 1.05,
              boxShadow: "0 10px 30px rgba(59, 130, 246, 0.4)"
            }}
            whileTap={{ scale: 0.95 }}
            className="btn-water relative overflow-hidden group px-8 py-4 bg-gradient-to-r from-blue-600 to-indigo-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300" data-id="gkhhdz9l6" data-path="src/components/FeatureCards.tsx">
            <span className="relative z-10" data-id="dep3vqv0j" data-path="src/components/FeatureCards.tsx">Dive Into All Features</span>
            
            {/* Water wave effect */}
            <motion.div
              className="absolute inset-0 bg-gradient-to-r from-cyan-400 to-blue-500 opacity-0 group-hover:opacity-20"
              animate={{
                x: ['-100%', '100%']
              }}
              transition={{
                duration: 1.5,
                repeat: Infinity,
                ease: "linear"
              }} data-id="1cbhuusax" data-path="src/components/FeatureCards.tsx" />

          </motion.button>
        </motion.div>
      </div>
    </section>);

};

export default FeatureCards;