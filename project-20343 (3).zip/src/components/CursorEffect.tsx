import React, { useEffect, useRef, useState } from 'react';

interface Position {
  x: number;
  y: number;
}

interface WaterDroplet {
  id: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  maxLife: number;
  size: number;
}

interface SplashEffect {
  id: number;
  x: number;
  y: number;
  timestamp: number;
}

const CursorEffect: React.FC = () => {
  const [mousePosition, setMousePosition] = useState<Position>({ x: 0, y: 0 });
  const [isClicking, setIsClicking] = useState(false);
  const [trails, setTrails] = useState<Position[]>([]);
  const [waterDroplets, setWaterDroplets] = useState<WaterDroplet[]>([]);
  const [splashEffects, setSplashEffects] = useState<SplashEffect[]>([]);
  const animationRef = useRef<number>();
  const dropletIdRef = useRef(0);
  const splashIdRef = useRef(0);

  useEffect(() => {
    let trailIndex = 0;
    const maxTrails = 12;

    const updateMousePosition = (e: MouseEvent) => {
      const newPosition = { x: e.clientX, y: e.clientY };
      setMousePosition(newPosition);

      // Update trails
      setTrails((prevTrails) => {
        const newTrails = [...prevTrails];
        newTrails[trailIndex] = newPosition;
        trailIndex = (trailIndex + 1) % maxTrails;
        if (newTrails.length < maxTrails) {
          newTrails.push(newPosition);
        }
        return newTrails;
      });

      // Create water droplets on movement
      if (Math.random() < 0.3) {
        createWaterDroplet(newPosition.x, newPosition.y);
      }
    };

    const handleMouseDown = () => {
      setIsClicking(true);
      // Create splash effect on click
      createSplashEffect(mousePosition.x, mousePosition.y);
    };

    const handleMouseUp = () => setIsClicking(false);

    document.addEventListener('mousemove', updateMousePosition);
    document.addEventListener('mousedown', handleMouseDown);
    document.addEventListener('mouseup', handleMouseUp);

    return () => {
      document.removeEventListener('mousemove', updateMousePosition);
      document.removeEventListener('mousedown', handleMouseDown);
      document.removeEventListener('mouseup', handleMouseUp);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [mousePosition.x, mousePosition.y]);

  const createWaterDroplet = (x: number, y: number) => {
    const droplet: WaterDroplet = {
      id: dropletIdRef.current++,
      x: x + (Math.random() - 0.5) * 40,
      y: y + (Math.random() - 0.5) * 40,
      vx: (Math.random() - 0.5) * 4,
      vy: (Math.random() - 0.5) * 4 + 2,
      life: 60,
      maxLife: 60,
      size: Math.random() * 6 + 3
    };

    setWaterDroplets((prev) => [...prev.slice(-20), droplet]);
  };

  const createSplashEffect = (x: number, y: number) => {
    const splash: SplashEffect = {
      id: splashIdRef.current++,
      x,
      y,
      timestamp: Date.now()
    };

    setSplashEffects((prev) => [...prev, splash]);

    // Create multiple droplets for splash
    for (let i = 0; i < 8; i++) {
      setTimeout(() => {
        createWaterDroplet(x, y);
      }, i * 50);
    }

    // Remove splash after animation
    setTimeout(() => {
      setSplashEffects((prev) => prev.filter((s) => s.id !== splash.id));
    }, 800);
  };

  // Animate water droplets
  useEffect(() => {
    const animate = () => {
      setWaterDroplets((prev) =>
      prev.map((droplet) => ({
        ...droplet,
        x: droplet.x + droplet.vx,
        y: droplet.y + droplet.vy,
        vy: droplet.vy + 0.2, // gravity
        life: droplet.life - 1
      })).filter((droplet) => droplet.life > 0)
      );

      animationRef.current = requestAnimationFrame(animate);
    };

    animationRef.current = requestAnimationFrame(animate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  return (
    <>
      {/* Main cursor glow with water effect */}
      <div
        className="cursor-glow-water"
        style={{
          left: mousePosition.x,
          top: mousePosition.y,
          transform: `translate(-50%, -50%) scale(${isClicking ? 1.8 : 1})`
        }} data-id="guafsue7r" data-path="src/components/CursorEffect.tsx" />

      {/* Enhanced cursor trails */}
      {trails.map((trail, index) =>
      <div
        key={index}
        className="cursor-trail-water"
        style={{
          left: trail.x,
          top: trail.y,
          opacity: (index + 1) / trails.length * 0.7,
          transform: `translate(-50%, -50%) scale(${(index + 1) / trails.length})`,
          animationDelay: `${index * 0.03}s`
        }} data-id="b54leutct" data-path="src/components/CursorEffect.tsx" />
      )}

      {/* Water droplets */}
      {waterDroplets.map((droplet) =>
      <div
        key={droplet.id}
        className="water-droplet"
        style={{
          left: droplet.x,
          top: droplet.y,
          opacity: droplet.life / droplet.maxLife * 0.8,
          transform: `translate(-50%, -50%) scale(${droplet.size / 10})`
        }} data-id="ha4hffpfp" data-path="src/components/CursorEffect.tsx" />
      )}

      {/* Click splash effects */}
      {splashEffects.map((splash) =>
      <div
        key={splash.id}
        className="water-splash"
        style={{
          left: splash.x,
          top: splash.y,
          transform: 'translate(-50%, -50%)'
        }} data-id="6u87q10s3" data-path="src/components/CursorEffect.tsx">
          <div className="splash-ring splash-ring-1" data-id="qpqmzv0i2" data-path="src/components/CursorEffect.tsx" />
          <div className="splash-ring splash-ring-2" data-id="8yod07307" data-path="src/components/CursorEffect.tsx" />
          <div className="splash-ring splash-ring-3" data-id="sya672bpk" data-path="src/components/CursorEffect.tsx" />
        </div>
      )}

      {/* Enhanced background water effect */}
      <div
        className="cursor-water-background"
        style={{
          background: `radial-gradient(circle 600px at ${mousePosition.x}px ${mousePosition.y}px, 
            rgba(59, 130, 246, 0.05) 0%, 
            rgba(99, 102, 241, 0.03) 25%, 
            rgba(139, 92, 246, 0.02) 50%, 
            transparent 70%)`
        }} data-id="hj0evnbhj" data-path="src/components/CursorEffect.tsx" />
      
      {/* Ocean wave cursor effect */}
      <div
        className="cursor-ocean-wave"
        style={{
          left: mousePosition.x,
          top: mousePosition.y
        }} data-id="a2iop3ng9" data-path="src/components/CursorEffect.tsx" />
    </>);

};

export default CursorEffect;