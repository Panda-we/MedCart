import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { X, Mail, Gift, Sparkles } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const NewsletterPopup = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [email, setEmail] = useState('');
  const [hasScrolled, setHasScrolled] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      const scrollPosition = window.scrollY;
      const windowHeight = window.innerHeight;
      const documentHeight = document.documentElement.scrollHeight;
      const scrollPercentage = scrollPosition / (documentHeight - windowHeight) * 100;

      if (scrollPercentage > 40 && !hasScrolled) {
        setHasScrolled(true);
        // Show popup after 2 seconds of reaching 40% scroll
        setTimeout(() => {
          setIsVisible(true);
        }, 2000);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [hasScrolled]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;

    setIsSubmitting(true);

    // Simulate API call
    setTimeout(() => {
      toast({
        title: "Welcome aboard! 🎉",
        description: "Thanks for subscribing! Check your email for exclusive content."
      });
      setIsSubmitting(false);
      setIsVisible(false);
    }, 1500);
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  return (
    <AnimatePresence data-id="rd8u4mksd" data-path="src/components/NewsletterPopup.tsx">
      {isVisible &&
      <>
          {/* Backdrop */}
          <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          onClick={handleClose} data-id="2ib3r734w" data-path="src/components/NewsletterPopup.tsx">

            {/* Popup Card */}
            <motion.div
            initial={{
              opacity: 0,
              scale: 0.8,
              y: 50,
              rotateX: -15
            }}
            animate={{
              opacity: 1,
              scale: 1,
              y: 0,
              rotateX: 0
            }}
            exit={{
              opacity: 0,
              scale: 0.8,
              y: 50,
              rotateX: 15
            }}
            transition={{
              duration: 0.5,
              ease: "easeOut",
              type: "spring",
              stiffness: 200,
              damping: 20
            }}
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-md w-full" data-id="egomfus1c" data-path="src/components/NewsletterPopup.tsx">

              <Card className="p-8 bg-gradient-to-br from-white via-purple-50 to-pink-50 border-0 shadow-2xl overflow-hidden" data-id="l9qe9oy48" data-path="src/components/NewsletterPopup.tsx">
                {/* Close Button */}
                <motion.button
                onClick={handleClose}
                className="absolute top-4 right-4 p-2 rounded-full bg-white/80 hover:bg-white transition-colors z-10"
                whileHover={{ scale: 1.1, rotate: 90 }}
                whileTap={{ scale: 0.9 }} data-id="wua8licy0" data-path="src/components/NewsletterPopup.tsx">

                  <X className="w-4 h-4 text-gray-500" data-id="ogfw4q2m4" data-path="src/components/NewsletterPopup.tsx" />
                </motion.button>

                {/* Background Decorations */}
                <div className="absolute inset-0 overflow-hidden" data-id="mhd8g3hsf" data-path="src/components/NewsletterPopup.tsx">
                  <motion.div
                  className="absolute -top-10 -right-10 w-32 h-32 rounded-full bg-gradient-to-br from-purple-400/20 to-pink-400/20"
                  animate={{
                    scale: [1, 1.2, 1],
                    rotate: [0, 180, 360]
                  }}
                  transition={{
                    duration: 8,
                    repeat: Infinity,
                    ease: "linear"
                  }} data-id="4aslavbf5" data-path="src/components/NewsletterPopup.tsx" />

                  <motion.div
                  className="absolute -bottom-6 -left-6 w-24 h-24 rounded-full bg-gradient-to-br from-blue-400/20 to-teal-400/20"
                  animate={{
                    scale: [1.2, 1, 1.2],
                    rotate: [360, 180, 0]
                  }}
                  transition={{
                    duration: 6,
                    repeat: Infinity,
                    ease: "linear"
                  }} data-id="f5yp185iv" data-path="src/components/NewsletterPopup.tsx" />

                </div>

                {/* Content */}
                <div className="relative z-10 text-center" data-id="of7zcp8z3" data-path="src/components/NewsletterPopup.tsx">
                  {/* Icon */}
                  <motion.div
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{
                    delay: 0.2,
                    type: "spring",
                    stiffness: 200,
                    duration: 0.6
                  }}
                  className="w-16 h-16 mx-auto mb-6 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 p-4 shadow-lg" data-id="llffnxbms" data-path="src/components/NewsletterPopup.tsx">

                    <Mail className="w-full h-full text-white" data-id="rl7ne7772" data-path="src/components/NewsletterPopup.tsx" />
                  </motion.div>

                  {/* Title with animation */}
                  <motion.h3
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.3, duration: 0.5 }}
                  className="text-2xl font-bold text-gray-900 mb-3" data-id="fi124lkuu" data-path="src/components/NewsletterPopup.tsx">

                    Join Our Community! 
                    <motion.span
                    animate={{ rotate: [0, 15, -15, 0] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="inline-block ml-2" data-id="crpiyhfxg" data-path="src/components/NewsletterPopup.tsx">

                      ✨
                    </motion.span>
                  </motion.h3>

                  {/* Subtitle */}
                  <motion.p
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4, duration: 0.5 }}
                  className="text-gray-600 mb-6 leading-relaxed" data-id="i56lio7le" data-path="src/components/NewsletterPopup.tsx">

                    Get exclusive access to premium content, early updates, and special offers. 
                    Join thousands of satisfied subscribers!
                  </motion.p>

                  {/* Benefits */}
                  <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.5, duration: 0.5 }}
                  className="flex items-center justify-center gap-6 mb-6 text-sm text-gray-500" data-id="zgdi57r1p" data-path="src/components/NewsletterPopup.tsx">

                    <div className="flex items-center gap-2" data-id="90ji1f5xo" data-path="src/components/NewsletterPopup.tsx">
                      <Gift className="w-4 h-4 text-purple-500" data-id="dqq3br5hq" data-path="src/components/NewsletterPopup.tsx" />
                      <span data-id="i43nx6oex" data-path="src/components/NewsletterPopup.tsx">Exclusive Content</span>
                    </div>
                    <div className="flex items-center gap-2" data-id="vhbjnm89p" data-path="src/components/NewsletterPopup.tsx">
                      <Sparkles className="w-4 h-4 text-pink-500" data-id="g9qrtzne3" data-path="src/components/NewsletterPopup.tsx" />
                      <span data-id="fuk2rtq3d" data-path="src/components/NewsletterPopup.tsx">Early Access</span>
                    </div>
                  </motion.div>

                  {/* Form */}
                  <motion.form
                  onSubmit={handleSubmit}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6, duration: 0.5 }}
                  className="space-y-4" data-id="eot1gekjv" data-path="src/components/NewsletterPopup.tsx">

                    <div className="relative" data-id="jyd768rms" data-path="src/components/NewsletterPopup.tsx">
                      <Input
                      type="email"
                      placeholder="Enter your email address"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full border-2 border-gray-200 focus:border-purple-500 transition-colors"
                      required data-id="9nwcuxvxw" data-path="src/components/NewsletterPopup.tsx" />

                      <motion.div
                      className="absolute inset-0 rounded-md border-2 border-purple-500"
                      initial={{ scale: 0, opacity: 0 }}
                      animate={{
                        scale: email ? 1 : 0,
                        opacity: email ? 0.3 : 0
                      }}
                      transition={{ duration: 0.2 }} data-id="fpgivlrem" data-path="src/components/NewsletterPopup.tsx" />

                    </div>

                    <Button
                    type="submit"
                    disabled={isSubmitting || !email}
                    className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white font-semibold py-3 shadow-lg hover:shadow-xl transition-all duration-300 disabled:opacity-50" data-id="2w9r2cq7u" data-path="src/components/NewsletterPopup.tsx">

                      {isSubmitting ?
                    <motion.div
                      animate={{ rotate: 360 }}
                      transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                      className="w-5 h-5 border-2 border-white border-t-transparent rounded-full" data-id="dwmx0ja0b" data-path="src/components/NewsletterPopup.tsx" /> :


                    <>
                          Subscribe Now
                          <motion.div
                        animate={{ x: [0, 5, 0] }}
                        transition={{ duration: 1.5, repeat: Infinity }}
                        className="ml-2" data-id="g2chsfdlf" data-path="src/components/NewsletterPopup.tsx">

                            →
                          </motion.div>
                        </>
                    }
                    </Button>
                  </motion.form>

                  {/* Trust indicators */}
                  <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8, duration: 0.5 }}
                  className="mt-6 text-xs text-gray-500 flex items-center justify-center gap-4" data-id="didr8vpub" data-path="src/components/NewsletterPopup.tsx">

                    <span data-id="vijidqbun" data-path="src/components/NewsletterPopup.tsx">🔒 100% Secure</span>
                    <span data-id="21ta089le" data-path="src/components/NewsletterPopup.tsx">•</span>
                    <span data-id="ttrfzt3ld" data-path="src/components/NewsletterPopup.tsx">📧 No Spam</span>
                    <span data-id="tyluuc9cs" data-path="src/components/NewsletterPopup.tsx">•</span>
                    <span data-id="fwzp8upjo" data-path="src/components/NewsletterPopup.tsx">❌ Unsubscribe Anytime</span>
                  </motion.div>
                </div>

                {/* Floating particles */}
                {[...Array(6)].map((_, i) =>
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-gradient-to-r from-purple-400 to-pink-400 rounded-full"
                style={{
                  left: `${10 + Math.random() * 80}%`,
                  top: `${10 + Math.random() * 80}%`
                }}
                animate={{
                  y: [0, -20, 0],
                  opacity: [0.3, 1, 0.3],
                  scale: [0.5, 1, 0.5]
                }}
                transition={{
                  duration: 2 + Math.random() * 2,
                  repeat: Infinity,
                  delay: Math.random() * 2
                }} data-id="eqocgq9ks" data-path="src/components/NewsletterPopup.tsx" />

              )}
              </Card>
            </motion.div>
          </motion.div>
        </>
      }
    </AnimatePresence>);

};

export default NewsletterPopup;