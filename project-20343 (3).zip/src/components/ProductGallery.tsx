import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Heart, ShoppingCart, Eye, Star } from 'lucide-react';

const ProductGallery: React.FC = () => {
  const [hoveredProduct, setHoveredProduct] = useState<number | null>(null);

  const products = [
  {
    id: 1,
    name: "Smart Blood Pressure Monitor",
    category: "Diagnostics",
    price: 299,
    originalPrice: 399,
    rating: 4.8,
    reviews: 234,
    image: "https://images.unsplash.com/photo-1505751172876-fa1923c5c528?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    badge: "Best Seller",
    description: "Advanced digital monitoring with smartphone connectivity"
  },
  {
    id: 2,
    name: "Digital Thermometer Pro",
    category: "Medical Devices",
    price: 89,
    originalPrice: 120,
    rating: 4.9,
    reviews: 456,
    image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    badge: "New",
    description: "Fast, accurate temperature readings in seconds"
  },
  {
    id: 3,
    name: "Pulse Oximeter Elite",
    category: "Monitoring",
    price: 149,
    originalPrice: 199,
    rating: 4.7,
    reviews: 189,
    image: "https://images.unsplash.com/photo-1631815589968-fdb09ba30bb5?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    badge: "Premium",
    description: "Professional-grade oxygen saturation monitoring"
  },
  {
    id: 4,
    name: "Smart Glucose Meter",
    category: "Diabetes Care",
    price: 179,
    originalPrice: 249,
    rating: 4.6,
    reviews: 298,
    image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    badge: "Featured",
    description: "Bluetooth-enabled glucose monitoring system"
  },
  {
    id: 5,
    name: "First Aid Kit Pro",
    category: "Emergency Care",
    price: 79,
    originalPrice: 99,
    rating: 4.5,
    reviews: 567,
    image: "https://images.unsplash.com/photo-1603398938884-24d6b8f91a5e?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    badge: "Essential",
    description: "Comprehensive emergency medical supplies"
  },
  {
    id: 6,
    name: "Wellness Scale Smart",
    category: "Health Monitoring",
    price: 199,
    originalPrice: 279,
    rating: 4.4,
    reviews: 145,
    image: "https://images.unsplash.com/photo-1594736797933-d0b22896a6e6?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&q=80",
    badge: "Tech",
    description: "Body composition analysis with app integration"
  }];


  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section className="py-24 bg-gradient-to-b from-black to-gray-900" data-id="1t9oy2n1r" data-path="src/components/ProductGallery.tsx">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-id="jgp51xtwl" data-path="src/components/ProductGallery.tsx">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16" data-id="uveo8yc9h" data-path="src/components/ProductGallery.tsx">

          <Badge className="mb-4 bg-emerald-400/10 text-emerald-400 border-emerald-400/20" data-id="ka007ok97" data-path="src/components/ProductGallery.tsx">
            Premium Collection
          </Badge>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6" data-id="psdt1ijt3" data-path="src/components/ProductGallery.tsx">
            Medical Products
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto" data-id="6ipa2t1r7" data-path="src/components/ProductGallery.tsx">
            Discover our curated selection of premium medical devices and healthcare products, 
            designed to meet the highest standards of quality and reliability.
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" data-id="t2rxkjr2e" data-path="src/components/ProductGallery.tsx">

          {products.map((product) =>
          <motion.div
            key={product.id}
            variants={itemVariants}
            onMouseEnter={() => setHoveredProduct(product.id)}
            onMouseLeave={() => setHoveredProduct(null)} data-id="x2vgxz1pg" data-path="src/components/ProductGallery.tsx">

              <Card className="bg-gray-800/50 border-gray-700 hover:border-emerald-400/50 transition-all duration-300 group overflow-hidden" data-id="dsltk51vg" data-path="src/components/ProductGallery.tsx">
                <div className="relative" data-id="lq54hta33" data-path="src/components/ProductGallery.tsx">
                  <motion.div
                  className="aspect-square overflow-hidden"
                  whileHover={{ scale: 1.05 }}
                  transition={{ duration: 0.3 }} data-id="jy05ti303" data-path="src/components/ProductGallery.tsx">

                    <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" data-id="1f6gu0sui" data-path="src/components/ProductGallery.tsx" />

                  </motion.div>
                  
                  <Badge className="absolute top-4 left-4 bg-emerald-400 text-black" data-id="v90ocbgvd" data-path="src/components/ProductGallery.tsx">
                    {product.badge}
                  </Badge>
                  
                  <motion.div
                  className="absolute top-4 right-4 flex flex-col space-y-2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{
                    opacity: hoveredProduct === product.id ? 1 : 0,
                    x: hoveredProduct === product.id ? 0 : 20
                  }}
                  transition={{ duration: 0.2 }} data-id="29bw1aqcu" data-path="src/components/ProductGallery.tsx">

                    <Button size="icon" variant="ghost" className="bg-black/50 hover:bg-emerald-400 hover:text-black text-white" data-id="tncb6pys6" data-path="src/components/ProductGallery.tsx">
                      <Heart className="h-4 w-4" data-id="77fztqpcn" data-path="src/components/ProductGallery.tsx" />
                    </Button>
                    <Button size="icon" variant="ghost" className="bg-black/50 hover:bg-emerald-400 hover:text-black text-white" data-id="bf2hly1fi" data-path="src/components/ProductGallery.tsx">
                      <Eye className="h-4 w-4" data-id="f64i3e6sg" data-path="src/components/ProductGallery.tsx" />
                    </Button>
                  </motion.div>
                </div>
                
                <CardContent className="p-6" data-id="i105m3tgr" data-path="src/components/ProductGallery.tsx">
                  <div className="flex items-center justify-between mb-2" data-id="qzg8v3dlp" data-path="src/components/ProductGallery.tsx">
                    <Badge variant="outline" className="text-xs text-emerald-400 border-emerald-400/30" data-id="n0k71x70r" data-path="src/components/ProductGallery.tsx">
                      {product.category}
                    </Badge>
                    <div className="flex items-center text-yellow-400" data-id="tfvjm0ehx" data-path="src/components/ProductGallery.tsx">
                      <Star className="h-4 w-4 fill-current" data-id="gyp4dg6tc" data-path="src/components/ProductGallery.tsx" />
                      <span className="text-sm text-gray-400 ml-1" data-id="lstxz6lci" data-path="src/components/ProductGallery.tsx">
                        {product.rating} ({product.reviews})
                      </span>
                    </div>
                  </div>
                  
                  <h3 className="text-lg font-semibold text-white mb-2 group-hover:text-emerald-400 transition-colors" data-id="y3err5qhs" data-path="src/components/ProductGallery.tsx">
                    {product.name}
                  </h3>
                  
                  <p className="text-sm text-gray-400 mb-4" data-id="6g4qrmcsu" data-path="src/components/ProductGallery.tsx">
                    {product.description}
                  </p>
                  
                  <div className="flex items-center justify-between" data-id="wh30q7bql" data-path="src/components/ProductGallery.tsx">
                    <div className="flex items-center space-x-2" data-id="st8zl04q7" data-path="src/components/ProductGallery.tsx">
                      <span className="text-2xl font-bold text-emerald-400" data-id="45poomcqm" data-path="src/components/ProductGallery.tsx">
                        ${product.price}
                      </span>
                      <span className="text-sm text-gray-500 line-through" data-id="amf2b9msk" data-path="src/components/ProductGallery.tsx">
                        ${product.originalPrice}
                      </span>
                    </div>
                    
                    <Button
                    size="sm"
                    className="bg-emerald-400 hover:bg-emerald-500 text-black font-semibold" data-id="1rvrul982" data-path="src/components/ProductGallery.tsx">

                      <ShoppingCart className="h-4 w-4 mr-2" data-id="hf6vmparw" data-path="src/components/ProductGallery.tsx" />
                      Add to Cart
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="text-center mt-12" data-id="uv94vwou0" data-path="src/components/ProductGallery.tsx">

          <Button
            size="lg"
            variant="outline"
            className="border-emerald-400 text-emerald-400 hover:bg-emerald-400 hover:text-black px-8 py-3 rounded-full" data-id="q02coxf8h" data-path="src/components/ProductGallery.tsx">

            View All Products
          </Button>
        </motion.div>
      </div>
    </section>);

};

export default ProductGallery;