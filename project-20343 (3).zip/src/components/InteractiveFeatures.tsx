import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Stethoscope,
  Activity,
  Shield,
  Truck,
  Award,
  Users,
  CheckCircle,
  ArrowRight } from
'lucide-react';

const InteractiveFeatures: React.FC = () => {
  const [activeFeature, setActiveFeature] = useState('diagnostics');

  const features = [
  {
    id: 'diagnostics',
    icon: Stethoscope,
    title: 'Diagnostic Equipment',
    subtitle: 'Professional-grade medical diagnostics',
    description: 'Advanced diagnostic tools used by healthcare professionals worldwide. Our equipment meets the highest medical standards and provides accurate, reliable results.',
    image: 'https://images.unsplash.com/photo-1581595220892-b0739db3ba8c?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    stats: [
    { label: 'Accuracy Rate', value: '99.8%' },
    { label: 'Response Time', value: '<2 sec' },
    { label: 'Certifications', value: 'FDA+CE' }]

  },
  {
    id: 'monitoring',
    icon: Activity,
    title: 'Health Monitoring',
    subtitle: 'Real-time health tracking solutions',
    description: 'Continuous monitoring devices that track vital signs and health metrics. Connect to your smartphone for real-time data and alerts.',
    image: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    stats: [
    { label: 'Battery Life', value: '30 days' },
    { label: 'Sync Speed', value: 'Instant' },
    { label: 'Compatibility', value: 'iOS+Android' }]

  },
  {
    id: 'safety',
    icon: Shield,
    title: 'Safety & Protection',
    subtitle: 'Premium safety equipment and PPE',
    description: 'High-quality personal protective equipment and safety gear. Designed to provide maximum protection while maintaining comfort and usability.',
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    stats: [
    { label: 'Protection Level', value: 'N95+' },
    { label: 'Comfort Rating', value: '4.9/5' },
    { label: 'Durability', value: '200+ hours' }]

  },
  {
    id: 'delivery',
    icon: Truck,
    title: 'Smart Delivery',
    subtitle: 'Intelligent logistics and delivery',
    description: 'Temperature-controlled delivery for sensitive medical supplies. Real-time tracking and specialized handling for pharmaceutical products.',
    image: 'https://images.unsplash.com/photo-1558618666-fcd25c85cd64?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80',
    stats: [
    { label: 'Delivery Speed', value: '2-24 hours' },
    { label: 'Temperature Control', value: '±0.5°C' },
    { label: 'Success Rate', value: '99.9%' }]

  }];


  const currentFeature = features.find((f) => f.id === activeFeature) || features[0];

  return (
    <section className="py-24 bg-black" data-id="njjy2z6ns" data-path="src/components/InteractiveFeatures.tsx">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-id="n34khndfx" data-path="src/components/InteractiveFeatures.tsx">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16" data-id="oetv5a8dn" data-path="src/components/InteractiveFeatures.tsx">

          <div className="flex items-center justify-center mb-4" data-id="020p5qq0m" data-path="src/components/InteractiveFeatures.tsx">
            <Award className="h-6 w-6 text-emerald-400 mr-2" data-id="zgjf0n1n7" data-path="src/components/InteractiveFeatures.tsx" />
            <span className="text-emerald-400 font-semibold" data-id="nglb18wqp" data-path="src/components/InteractiveFeatures.tsx">Interactive Features</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6" data-id="hk8g6nz3t" data-path="src/components/InteractiveFeatures.tsx">
            Explore Our Solutions
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto" data-id="lcximnd8d" data-path="src/components/InteractiveFeatures.tsx">
            Discover the advanced features and capabilities that make our medical products 
            the choice of healthcare professionals worldwide.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center" data-id="lwe03jskf" data-path="src/components/InteractiveFeatures.tsx">
          {/* Feature Selection */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }} data-id="j3e1oq5ad" data-path="src/components/InteractiveFeatures.tsx">

            <Tabs value={activeFeature} onValueChange={setActiveFeature} orientation="vertical" data-id="pzp6v8b6w" data-path="src/components/InteractiveFeatures.tsx">
              <TabsList className="flex flex-col h-auto bg-gray-800/50 p-2 space-y-2" data-id="wbshbfm84" data-path="src/components/InteractiveFeatures.tsx">
                {features.map((feature) =>
                <TabsTrigger
                  key={feature.id}
                  value={feature.id}
                  className="w-full justify-start p-4 data-[state=active]:bg-emerald-400 data-[state=active]:text-black text-white hover:bg-gray-700" data-id="9y1m6oygx" data-path="src/components/InteractiveFeatures.tsx">

                    <feature.icon className="h-5 w-5 mr-3" data-id="8go49p0wf" data-path="src/components/InteractiveFeatures.tsx" />
                    <div className="text-left" data-id="33okc10cz" data-path="src/components/InteractiveFeatures.tsx">
                      <div className="font-semibold" data-id="fj5xeepl5" data-path="src/components/InteractiveFeatures.tsx">{feature.title}</div>
                      <div className="text-sm opacity-70" data-id="4ov6naytx" data-path="src/components/InteractiveFeatures.tsx">{feature.subtitle}</div>
                    </div>
                  </TabsTrigger>
                )}
              </TabsList>
            </Tabs>
          </motion.div>

          {/* Feature Content */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }} data-id="ecx2gfga1" data-path="src/components/InteractiveFeatures.tsx">

            <AnimatePresence mode="wait" data-id="dkl87sj87" data-path="src/components/InteractiveFeatures.tsx">
              <motion.div
                key={activeFeature}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }} data-id="nlaw6btri" data-path="src/components/InteractiveFeatures.tsx">

                <Card className="bg-gray-800/50 border-gray-700 overflow-hidden" data-id="xbuw3l6ho" data-path="src/components/InteractiveFeatures.tsx">
                  <div className="aspect-video relative overflow-hidden" data-id="8llf1cg2o" data-path="src/components/InteractiveFeatures.tsx">
                    <img
                      src={currentFeature.image}
                      alt={currentFeature.title}
                      className="w-full h-full object-cover" data-id="fqj4v54vz" data-path="src/components/InteractiveFeatures.tsx" />

                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" data-id="w3xu7nzde" data-path="src/components/InteractiveFeatures.tsx" />
                  </div>
                  
                  <CardContent className="p-8" data-id="o41694kia" data-path="src/components/InteractiveFeatures.tsx">
                    <div className="flex items-center mb-4" data-id="jcylbm4xa" data-path="src/components/InteractiveFeatures.tsx">
                      <currentFeature.icon className="h-8 w-8 text-emerald-400 mr-3" data-id="n9eo628o5" data-path="src/components/InteractiveFeatures.tsx" />
                      <div data-id="bvl0azq4q" data-path="src/components/InteractiveFeatures.tsx">
                        <h3 className="text-2xl font-bold text-white" data-id="1vk9csr0s" data-path="src/components/InteractiveFeatures.tsx">
                          {currentFeature.title}
                        </h3>
                        <p className="text-emerald-400" data-id="ehiwdjvb3" data-path="src/components/InteractiveFeatures.tsx">{currentFeature.subtitle}</p>
                      </div>
                    </div>
                    
                    <p className="text-gray-300 mb-6 leading-relaxed" data-id="52gfk9mea" data-path="src/components/InteractiveFeatures.tsx">
                      {currentFeature.description}
                    </p>
                    
                    <div className="grid grid-cols-3 gap-4 mb-6" data-id="ruyokb03y" data-path="src/components/InteractiveFeatures.tsx">
                      {currentFeature.stats.map((stat, index) =>
                      <div key={index} className="text-center" data-id="42sdri1d7" data-path="src/components/InteractiveFeatures.tsx">
                          <div className="text-2xl font-bold text-emerald-400" data-id="tbtwy2ctj" data-path="src/components/InteractiveFeatures.tsx">
                            {stat.value}
                          </div>
                          <div className="text-sm text-gray-400" data-id="diykql2ru" data-path="src/components/InteractiveFeatures.tsx">
                            {stat.label}
                          </div>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex space-x-4" data-id="r1ba7hroc" data-path="src/components/InteractiveFeatures.tsx">
                      <Button className="bg-emerald-400 hover:bg-emerald-500 text-black font-semibold flex-1" data-id="h7npxyn0d" data-path="src/components/InteractiveFeatures.tsx">
                        Learn More
                        <ArrowRight className="ml-2 h-4 w-4" data-id="v51rr07nw" data-path="src/components/InteractiveFeatures.tsx" />
                      </Button>
                      <Button variant="outline" className="border-gray-600 text-white hover:bg-gray-700" data-id="w1cmc7cl7" data-path="src/components/InteractiveFeatures.tsx">
                        <Users className="h-4 w-4 mr-2" data-id="b6oowlwyd" data-path="src/components/InteractiveFeatures.tsx" />
                        Contact Expert
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            </AnimatePresence>
          </motion.div>
        </div>

        {/* Feature Benefits */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-8" data-id="f8aqtaaz4" data-path="src/components/InteractiveFeatures.tsx">

          {[
          {
            icon: CheckCircle,
            title: "Certified Quality",
            description: "All products meet international medical standards"
          },
          {
            icon: Users,
            title: "Expert Support",
            description: "24/7 technical support from medical professionals"
          },
          {
            icon: Award,
            title: "Trusted Brand",
            description: "Used by healthcare facilities worldwide"
          }].
          map((benefit, index) =>
          <Card key={index} className="bg-gray-800/30 border-gray-700 text-center" data-id="v64k8r8v8" data-path="src/components/InteractiveFeatures.tsx">
              <CardContent className="p-6" data-id="4j6e19hpp" data-path="src/components/InteractiveFeatures.tsx">
                <benefit.icon className="h-8 w-8 text-emerald-400 mx-auto mb-4" data-id="2zckp3onz" data-path="src/components/InteractiveFeatures.tsx" />
                <h4 className="font-semibold text-white mb-2" data-id="y4h41x1rg" data-path="src/components/InteractiveFeatures.tsx">{benefit.title}</h4>
                <p className="text-gray-400 text-sm" data-id="2pznmk5bx" data-path="src/components/InteractiveFeatures.tsx">{benefit.description}</p>
              </CardContent>
            </Card>
          )}
        </motion.div>
      </div>
    </section>);

};

export default InteractiveFeatures;