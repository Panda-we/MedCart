import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '@/contexts/ThemeContext';
import { Button } from '@/components/ui/button';
import { Menu, X, Sun, Moon, ShoppingCart, Heart, User } from 'lucide-react';

const Navbar: React.FC = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { theme, toggleTheme } = useTheme();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
  { name: 'Home', href: '#hero' },
  { name: 'Products', href: '#products' },
  { name: 'Features', href: '#features' },
  { name: 'About', href: '#showcase' },
  { name: 'Contact', href: '#testimonials' }];


  return (
    <motion.nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      isScrolled ?
      'bg-black/90 backdrop-blur-md border-b border-gray-800' :
      'bg-transparent'}`
      }
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5 }} data-id="gjduxof7q" data-path="src/components/Navbar.tsx">

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-id="wr1tssfxl" data-path="src/components/Navbar.tsx">
        <div className="flex justify-between items-center h-16" data-id="zcn7qo870" data-path="src/components/Navbar.tsx">
          {/* Logo */}
          <motion.div
            className="flex items-center space-x-2"
            whileHover={{ scale: 1.05 }}
            transition={{ type: "spring", stiffness: 300 }} data-id="vd5vw1n5w" data-path="src/components/Navbar.tsx">

            <div className="w-8 h-8 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-lg flex items-center justify-center" data-id="ur4jbecte" data-path="src/components/Navbar.tsx">
              <span className="text-black font-bold text-sm" data-id="j3ht15wu0" data-path="src/components/Navbar.tsx">M</span>
            </div>
            <span className="text-xl font-bold text-white" data-id="qby9ttgrn" data-path="src/components/Navbar.tsx">MEDCART</span>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8" data-id="j2irgca7k" data-path="src/components/Navbar.tsx">
            {navItems.map((item, index) =>
            <motion.a
              key={item.name}
              href={item.href}
              className="text-gray-300 hover:text-emerald-400 transition-colors duration-200 text-sm font-medium"
              whileHover={{ y: -2 }}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }} data-id="q05darpoz" data-path="src/components/Navbar.tsx">

                {item.name}
              </motion.a>
            )}
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-4" data-id="b7ec5acoc" data-path="src/components/Navbar.tsx">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              className="text-gray-400 hover:text-emerald-400 hover:bg-gray-800" data-id="oh3ytadqn" data-path="src/components/Navbar.tsx">

              {theme === 'dark' ? <Sun className="h-4 w-4" data-id="boqmqw0ct" data-path="src/components/Navbar.tsx" /> : <Moon className="h-4 w-4" data-id="hy6yv0mqm" data-path="src/components/Navbar.tsx" />}
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-400 hover:text-emerald-400 hover:bg-gray-800 hidden sm:flex" data-id="ivl7wp9lg" data-path="src/components/Navbar.tsx">

              <Heart className="h-4 w-4" data-id="188sglxsz" data-path="src/components/Navbar.tsx" />
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-400 hover:text-emerald-400 hover:bg-gray-800 relative" data-id="ky6ftpo4s" data-path="src/components/Navbar.tsx">

              <ShoppingCart className="h-4 w-4" data-id="wy9tp8kz2" data-path="src/components/Navbar.tsx" />
              <span className="absolute -top-1 -right-1 bg-emerald-400 text-black text-xs rounded-full w-4 h-4 flex items-center justify-center" data-id="h3pjt0lsp" data-path="src/components/Navbar.tsx">
                3
              </span>
            </Button>
            
            <Button
              variant="ghost"
              size="icon"
              className="text-gray-400 hover:text-emerald-400 hover:bg-gray-800 hidden sm:flex" data-id="hdygym2cr" data-path="src/components/Navbar.tsx">

              <User className="h-4 w-4" data-id="rs6mcprtf" data-path="src/components/Navbar.tsx" />
            </Button>

            {/* Mobile menu button */}
            <Button
              variant="ghost"
              size="icon"
              className="md:hidden text-gray-400 hover:text-emerald-400"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} data-id="fp5w2v0gd" data-path="src/components/Navbar.tsx">

              {isMobileMenuOpen ? <X className="h-5 w-5" data-id="2szpd8j6x" data-path="src/components/Navbar.tsx" /> : <Menu className="h-5 w-5" data-id="rp5uxbaao" data-path="src/components/Navbar.tsx" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMobileMenuOpen &&
        <motion.div
          className="md:hidden bg-black/95 backdrop-blur-md border-t border-gray-800"
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          transition={{ duration: 0.3 }} data-id="vqxpaze52" data-path="src/components/Navbar.tsx">

            <div className="px-2 pt-2 pb-3 space-y-1" data-id="8b9pax7hp" data-path="src/components/Navbar.tsx">
              {navItems.map((item) =>
            <a
              key={item.name}
              href={item.href}
              className="block px-3 py-2 text-gray-300 hover:text-emerald-400 hover:bg-gray-800 rounded-md transition-colors duration-200"
              onClick={() => setIsMobileMenuOpen(false)} data-id="d9ujw64vu" data-path="src/components/Navbar.tsx">

                  {item.name}
                </a>
            )}
            </div>
          </motion.div>
        }
      </div>
    </motion.nav>);

};

export default Navbar;