import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { ExternalLink, Github, Eye, Code } from 'lucide-react';

const ShowcasePortfolio = () => {
  const [filter, setFilter] = useState('All');
  const [hoveredCard, setHoveredCard] = useState<number | null>(null);
  const [ripples, setRipples] = useState<{[key: number]: {x: number;y: number;id: number;}[];}>({});

  const categories = ['All', 'Web Apps', 'Mobile', 'AI/ML', 'E-commerce', 'SaaS'];

  const projects = [
  {
    id: 1,
    title: "AI-Powered Analytics Dashboard",
    description: "Advanced analytics platform with machine learning insights and real-time data visualization.",
    image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    category: "AI/ML",
    tags: ["React", "Python", "TensorFlow", "D3.js"],
    liveUrl: "#",
    githubUrl: "#",
    gradient: "from-purple-500 to-pink-500"
  },
  {
    id: 2,
    title: "E-commerce Mobile App",
    description: "Modern shopping experience with AR try-on features and seamless payment integration.",
    image: "https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    category: "Mobile",
    tags: ["React Native", "Node.js", "Stripe", "AR Kit"],
    liveUrl: "#",
    githubUrl: "#",
    gradient: "from-green-500 to-teal-500"
  },
  {
    id: 3,
    title: "SaaS Project Management Tool",
    description: "Collaborative workspace with advanced project tracking, team communication, and automation features.",
    image: "https://images.unsplash.com/photo-1611224923853-80b023f02d71?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    category: "SaaS",
    tags: ["Vue.js", "Laravel", "Redis", "WebSocket"],
    liveUrl: "#",
    githubUrl: "#",
    gradient: "from-blue-500 to-indigo-500"
  },
  {
    id: 4,
    title: "Real Estate Platform",
    description: "Comprehensive property management system with virtual tours and advanced search capabilities.",
    image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    category: "Web Apps",
    tags: ["Next.js", "PostgreSQL", "Mapbox", "Three.js"],
    liveUrl: "#",
    githubUrl: "#",
    gradient: "from-orange-500 to-red-500"
  },
  {
    id: 5,
    title: "Crypto Trading Platform",
    description: "Advanced cryptocurrency exchange with real-time trading, portfolio management, and security features.",
    image: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    category: "Web Apps",
    tags: ["React", "WebSocket", "Chart.js", "Node.js"],
    liveUrl: "#",
    githubUrl: "#",
    gradient: "from-yellow-500 to-orange-500"
  },
  {
    id: 6,
    title: "Healthcare Management System",
    description: "Comprehensive healthcare platform with patient records, appointment scheduling, and telemedicine features.",
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80",
    category: "Web Apps",
    tags: ["Angular", "MongoDB", "WebRTC", "Docker"],
    liveUrl: "#",
    githubUrl: "#",
    gradient: "from-teal-500 to-green-500"
  }];


  const filteredProjects = filter === 'All' ?
  projects :
  projects.filter((project) => project.category === filter);

  const createRipple = (cardId: number, event: React.MouseEvent<HTMLDivElement>) => {
    const rect = event.currentTarget.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    const newRipple = { x, y, id: Date.now() };

    setRipples((prev) => ({
      ...prev,
      [cardId]: [...(prev[cardId] || []), newRipple]
    }));

    setTimeout(() => {
      setRipples((prev) => ({
        ...prev,
        [cardId]: prev[cardId]?.filter((ripple) => ripple.id !== newRipple.id) || []
      }));
    }, 600);
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: {
      opacity: 0,
      y: 50,
      scale: 0.9
    },
    visible: {
      opacity: 1,
      y: 0,
      scale: 1,
      transition: {
        duration: 0.6,
        ease: "easeOut"
      }
    }
  };

  return (
    <section className="py-24 bg-gradient-to-br from-gray-50 via-white to-purple-50" data-id="fadk7b20z" data-path="src/components/ShowcasePortfolio.tsx">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-id="t29zlqe28" data-path="src/components/ShowcasePortfolio.tsx">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16" data-id="8ezh7alru" data-path="src/components/ShowcasePortfolio.tsx">

          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6" data-id="3785lvqmk" data-path="src/components/ShowcasePortfolio.tsx">
            Our
            <span className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent" data-id="3hsbwp9i1" data-path="src/components/ShowcasePortfolio.tsx"> Showcase</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto mb-8" data-id="6c0fiol33" data-path="src/components/ShowcasePortfolio.tsx">
            Explore our portfolio of innovative projects that demonstrate our expertise 
            across various industries and technologies.
          </p>

          {/* Filter Buttons */}
          <div className="flex flex-wrap justify-center gap-3" data-id="qosg4ce9x" data-path="src/components/ShowcasePortfolio.tsx">
            {categories.map((category) =>
            <motion.button
              key={category}
              onClick={() => setFilter(category)}
              className={`px-6 py-2 rounded-full transition-all duration-300 ${
              filter === category ?
              'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-lg' :
              'bg-white text-gray-600 hover:bg-gray-100 border border-gray-200'}`
              }
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }} data-id="scdfs0rr8" data-path="src/components/ShowcasePortfolio.tsx">

                {category}
              </motion.button>
            )}
          </div>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-100px" }}
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-8" data-id="u4jmmy879" data-path="src/components/ShowcasePortfolio.tsx">

          <AnimatePresence mode="wait" data-id="9l9lra2mp" data-path="src/components/ShowcasePortfolio.tsx">
            {filteredProjects.map((project) =>
            <motion.div
              key={project.id}
              variants={itemVariants}
              layout
              whileHover={{ y: -10 }}
              onMouseEnter={() => setHoveredCard(project.id)}
              onMouseLeave={() => setHoveredCard(null)} data-id="q0qe2zi4f" data-path="src/components/ShowcasePortfolio.tsx">

                <Card
                className="h-full border-0 shadow-lg hover:shadow-2xl transition-all duration-500 bg-white group overflow-hidden cursor-pointer relative"
                onClick={(e) => createRipple(project.id, e)} data-id="jtha7b57r" data-path="src/components/ShowcasePortfolio.tsx">

                  {/* Ripple Effects */}
                  {ripples[project.id]?.map((ripple) =>
                <motion.div
                  key={ripple.id}
                  className="absolute pointer-events-none bg-white/30 rounded-full"
                  style={{
                    left: ripple.x - 50,
                    top: ripple.y - 50,
                    width: 100,
                    height: 100
                  }}
                  initial={{ scale: 0, opacity: 0.6 }}
                  animate={{ scale: 4, opacity: 0 }}
                  transition={{ duration: 0.6, ease: "easeOut" }} data-id="myi01azf3" data-path="src/components/ShowcasePortfolio.tsx" />

                )}

                  {/* Project Image */}
                  <div className="relative overflow-hidden" data-id="5omnpvfla" data-path="src/components/ShowcasePortfolio.tsx">
                    <motion.img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-48 object-cover transition-transform duration-700 group-hover:scale-110"
                    whileHover={{ scale: 1.1 }} data-id="21mkxdzg8" data-path="src/components/ShowcasePortfolio.tsx" />

                    
                    {/* Overlay */}
                    <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300" data-id="xf4ymax26" data-path="src/components/ShowcasePortfolio.tsx">
                      <div className="flex items-center justify-center h-full gap-4" data-id="simdvi07s" data-path="src/components/ShowcasePortfolio.tsx">
                        <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="p-3 bg-white/20 backdrop-blur-sm rounded-full text-white hover:bg-white/30 transition-colors" data-id="de4l173sv" data-path="src/components/ShowcasePortfolio.tsx">

                          <Eye className="w-5 h-5" data-id="126e4b3ar" data-path="src/components/ShowcasePortfolio.tsx" />
                        </motion.button>
                        <motion.button
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                        className="p-3 bg-white/20 backdrop-blur-sm rounded-full text-white hover:bg-white/30 transition-colors" data-id="dezglkcsd" data-path="src/components/ShowcasePortfolio.tsx">

                          <Code className="w-5 h-5" data-id="f0yqzemyt" data-path="src/components/ShowcasePortfolio.tsx" />
                        </motion.button>
                      </div>
                    </div>

                    {/* Category Badge */}
                    <div className="absolute top-4 left-4" data-id="g2h9fp8oz" data-path="src/components/ShowcasePortfolio.tsx">
                      <Badge className={`bg-gradient-to-r ${project.gradient} text-white border-0`} data-id="884v3gv0u" data-path="src/components/ShowcasePortfolio.tsx">
                        {project.category}
                      </Badge>
                    </div>
                  </div>

                  <CardContent className="p-6 relative" data-id="kc6kf5oz7" data-path="src/components/ShowcasePortfolio.tsx">
                    {/* Gradient Background */}
                    <div className={`absolute inset-0 bg-gradient-to-br ${project.gradient} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} data-id="3pub6fhv1" data-path="src/components/ShowcasePortfolio.tsx" />
                    
                    <div className="relative z-10" data-id="fcad9xwr0" data-path="src/components/ShowcasePortfolio.tsx">
                      <h3 className="text-xl font-bold text-gray-900 mb-3 group-hover:text-gray-800 transition-colors" data-id="onp7583ed" data-path="src/components/ShowcasePortfolio.tsx">
                        {project.title}
                      </h3>
                      
                      <p className="text-gray-600 mb-4 leading-relaxed group-hover:text-gray-700 transition-colors" data-id="ftxk84rl4" data-path="src/components/ShowcasePortfolio.tsx">
                        {project.description}
                      </p>

                      {/* Tags */}
                      <div className="flex flex-wrap gap-2 mb-6" data-id="i318pk9w5" data-path="src/components/ShowcasePortfolio.tsx">
                        {project.tags.map((tag, index) =>
                      <motion.span
                        key={index}
                        className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm font-medium hover:bg-gray-200 transition-colors"
                        initial={{ opacity: 0, scale: 0.8 }}
                        animate={{ opacity: 1, scale: 1 }}
                        transition={{ delay: index * 0.1, duration: 0.3 }} data-id="byu8hzuja" data-path="src/components/ShowcasePortfolio.tsx">

                            {tag}
                          </motion.span>
                      )}
                      </div>

                      {/* Action Buttons */}
                      <div className="flex gap-3" data-id="dnlibmpck" data-path="src/components/ShowcasePortfolio.tsx">
                        <Button
                        size="sm"
                        className={`bg-gradient-to-r ${project.gradient} text-white border-0 hover:shadow-lg transition-all duration-300 flex items-center gap-2`} data-id="xve2rswc6" data-path="src/components/ShowcasePortfolio.tsx">

                          <ExternalLink className="w-4 h-4" data-id="14npyadcq" data-path="src/components/ShowcasePortfolio.tsx" />
                          Live Demo
                        </Button>
                        <Button
                        size="sm"
                        variant="outline"
                        className="border-gray-300 text-gray-600 hover:bg-gray-50 flex items-center gap-2" data-id="8taajgzk3" data-path="src/components/ShowcasePortfolio.tsx">

                          <Github className="w-4 h-4" data-id="14pjyelbo" data-path="src/components/ShowcasePortfolio.tsx" />
                          Code
                        </Button>
                      </div>
                    </div>

                    {/* Floating Particles */}
                    {hoveredCard === project.id &&
                  <>
                        <motion.div
                      className="absolute top-4 right-4 w-2 h-2 rounded-full bg-gradient-to-r from-purple-400 to-pink-400"
                      animate={{
                        y: [0, -15, 0],
                        opacity: [0.5, 1, 0.5]
                      }}
                      transition={{
                        duration: 2,
                        repeat: Infinity
                      }} data-id="uvrfh98dc" data-path="src/components/ShowcasePortfolio.tsx" />

                        
                        <motion.div
                      className="absolute bottom-8 left-6 w-1 h-1 rounded-full bg-gradient-to-r from-blue-400 to-teal-400"
                      animate={{
                        x: [0, 10, 0],
                        opacity: [0.3, 1, 0.3]
                      }}
                      transition={{
                        duration: 3,
                        repeat: Infinity
                      }} data-id="t9fun9pd1" data-path="src/components/ShowcasePortfolio.tsx" />

                      </>
                  }

                    {/* Progress Bar */}
                    <motion.div
                    className={`absolute bottom-0 left-0 h-1 bg-gradient-to-r ${project.gradient}`}
                    initial={{ width: 0 }}
                    whileInView={{ width: '100%' }}
                    viewport={{ once: true }}
                    transition={{
                      delay: 0.5,
                      duration: 1.5,
                      ease: "easeOut"
                    }} data-id="08mamzel5" data-path="src/components/ShowcasePortfolio.tsx" />

                  </CardContent>
                </Card>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Call to Action */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.5, duration: 0.6 }}
          className="text-center mt-16" data-id="0d1clw2ge" data-path="src/components/ShowcasePortfolio.tsx">

          <motion.button
            whileHover={{
              scale: 1.05,
              boxShadow: "0 10px 30px rgba(147, 51, 234, 0.3)"
            }}
            whileTap={{ scale: 0.95 }}
            className="px-8 py-4 bg-gradient-to-r from-purple-600 to-pink-600 text-white font-semibold rounded-xl shadow-lg hover:shadow-xl transition-all duration-300" data-id="rodseb8ir" data-path="src/components/ShowcasePortfolio.tsx">

            View All Projects
          </motion.button>
        </motion.div>
      </div>
    </section>);

};

export default ShowcasePortfolio;