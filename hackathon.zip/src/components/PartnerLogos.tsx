import React from 'react';
import { motion } from 'framer-motion';

const PartnerLogos: React.FC = () => {
  const partners = [
  {
    name: "Mayo Clinic",
    logo: "https://images.unsplash.com/photo-1516549655169-df83a0774514?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=100&q=80"
  },
  {
    name: "Johns Hopkins",
    logo: "https://images.unsplash.com/photo-1559757148-5c350d0d3c56?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=100&q=80"
  },
  {
    name: "Cleveland Clinic",
    logo: "https://images.unsplash.com/photo-1538108149393-fbbd81895907?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=100&q=80"
  },
  {
    name: "Massachusetts General",
    logo: "https://images.unsplash.com/photo-1551190822-a9333d879b1f?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=100&q=80"
  },
  {
    name: "UCLA Medical",
    logo: "https://images.unsplash.com/photo-1582750433449-648ed127bb54?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=100&q=80"
  },
  {
    name: "Stanford Medicine",
    logo: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?ixlib=rb-4.0.3&auto=format&fit=crop&w=200&h=100&q=80"
  }];


  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  };

  return (
    <section className="py-24 bg-gradient-to-b from-gray-900 to-black" data-id="oicitchhi" data-path="src/components/PartnerLogos.tsx">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-id="e13zb3wl7" data-path="src/components/PartnerLogos.tsx">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16" data-id="lzsz9n49k" data-path="src/components/PartnerLogos.tsx">

          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4" data-id="jdyuxkqyo" data-path="src/components/PartnerLogos.tsx">
            Trusted by Leading Healthcare Institutions
          </h2>
          <p className="text-xl text-gray-400 max-w-2xl mx-auto" data-id="gu0rbbzzn" data-path="src/components/PartnerLogos.tsx">
            Our medical products are used by top hospitals and healthcare providers around the world
          </p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center" data-id="77k8yxatw" data-path="src/components/PartnerLogos.tsx">

          {partners.map((partner, index) =>
          <motion.div
            key={index}
            variants={itemVariants}
            whileHover={{
              scale: 1.1,
              y: -10,
              transition: { type: "spring", stiffness: 300 }
            }}
            className="relative group" data-id="ik9ul2go1" data-path="src/components/PartnerLogos.tsx">

              <div className="bg-gray-800/50 rounded-lg p-6 border border-gray-700 hover:border-emerald-400/50 transition-all duration-300" data-id="dwaqv85p7" data-path="src/components/PartnerLogos.tsx">
                <div className="aspect-video relative overflow-hidden rounded-md" data-id="u4mc241uu" data-path="src/components/PartnerLogos.tsx">
                  <img
                  src={partner.logo}
                  alt={partner.name}
                  className="w-full h-full object-cover filter grayscale group-hover:grayscale-0 transition-all duration-300" data-id="ehpdctlp4" data-path="src/components/PartnerLogos.tsx" />

                  <div className="absolute inset-0 bg-black/20 group-hover:bg-transparent transition-all duration-300" data-id="f2ykfilo1" data-path="src/components/PartnerLogos.tsx" />
                </div>
                <h3 className="text-sm font-semibold text-gray-400 group-hover:text-emerald-400 text-center mt-3 transition-colors duration-300" data-id="6g5jrt7xf" data-path="src/components/PartnerLogos.tsx">
                  {partner.name}
                </h3>
              </div>
              
              {/* Floating animation effect */}
              <motion.div
              className="absolute -top-2 -right-2 w-4 h-4 bg-emerald-400 rounded-full opacity-0 group-hover:opacity-100"
              animate={{
                y: [0, -10, 0],
                scale: [1, 1.2, 1]
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatType: "reverse"
              }} data-id="qnvyhon7y" data-path="src/components/PartnerLogos.tsx" />

            </motion.div>
          )}
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className="mt-16 text-center" data-id="jhv2cqr8b" data-path="src/components/PartnerLogos.tsx">

          <div className="inline-flex items-center space-x-8 text-gray-400" data-id="065y1y0ym" data-path="src/components/PartnerLogos.tsx">
            <div className="flex items-center space-x-2" data-id="usj1fjisl" data-path="src/components/PartnerLogos.tsx">
              <div className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse" data-id="e3eundho0" data-path="src/components/PartnerLogos.tsx" />
              <span className="text-sm" data-id="ibivaj1ke" data-path="src/components/PartnerLogos.tsx">500+ Healthcare Partners</span>
            </div>
            <div className="flex items-center space-x-2" data-id="q5o5qmklj" data-path="src/components/PartnerLogos.tsx">
              <div className="w-3 h-3 bg-blue-400 rounded-full animate-pulse" data-id="juvhal2tn" data-path="src/components/PartnerLogos.tsx" />
              <span className="text-sm" data-id="vwiwzz7zt" data-path="src/components/PartnerLogos.tsx">50+ Countries Served</span>
            </div>
            <div className="flex items-center space-x-2" data-id="04wygzkbn" data-path="src/components/PartnerLogos.tsx">
              <div className="w-3 h-3 bg-purple-400 rounded-full animate-pulse" data-id="1fkc5l5fx" data-path="src/components/PartnerLogos.tsx" />
              <span className="text-sm" data-id="kdpteypf4" data-path="src/components/PartnerLogos.tsx">99.9% Uptime</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>);

};

export default PartnerLogos;