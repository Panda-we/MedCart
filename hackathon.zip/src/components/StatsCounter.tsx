import React, { useRef, useEffect, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import CountUp from 'react-countup';
import { TrendingUp, Users, Globe, Award, Zap, Heart } from 'lucide-react';

const StatsCounter = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [startAnimation, setStartAnimation] = useState(false);

  useEffect(() => {
    if (isInView) {
      setStartAnimation(true);
    }
  }, [isInView]);

  const stats = [
  {
    icon: Users,
    value: 250000,
    suffix: "+",
    label: "Active Users",
    description: "Growing community worldwide",
    color: "from-blue-500 to-cyan-500",
    delay: 0.1
  },
  {
    icon: Globe,
    value: 150,
    suffix: "+",
    label: "Countries",
    description: "Global presence established",
    color: "from-green-500 to-emerald-500",
    delay: 0.2
  },
  {
    icon: TrendingUp,
    value: 99.9,
    suffix: "%",
    label: "Uptime",
    description: "Reliable service guarantee",
    color: "from-purple-500 to-violet-500",
    delay: 0.3
  },
  {
    icon: Award,
    value: 50,
    suffix: "+",
    label: "Awards Won",
    description: "Industry recognition received",
    color: "from-yellow-500 to-orange-500",
    delay: 0.4
  },
  {
    icon: Zap,
    value: 2.5,
    suffix: "B+",
    label: "API Calls",
    description: "Monthly requests processed",
    color: "from-pink-500 to-rose-500",
    delay: 0.5
  },
  {
    icon: Heart,
    value: 98,
    suffix: "%",
    label: "Satisfaction",
    description: "Customer happiness rate",
    color: "from-red-500 to-pink-500",
    delay: 0.6
  }];


  // SVG Graph Component
  const AnimatedGraph = () => {
    const graphData = [
    { month: 'Jan', value: 400 },
    { month: 'Feb', value: 300 },
    { month: 'Mar', value: 600 },
    { month: 'Apr', value: 800 },
    { month: 'May', value: 500 },
    { month: 'Jun', value: 900 },
    { month: 'Jul', value: 1200 },
    { month: 'Aug', value: 1000 },
    { month: 'Sep', value: 1400 },
    { month: 'Oct', value: 1100 },
    { month: 'Nov', value: 1600 },
    { month: 'Dec', value: 1800 }];


    const maxValue = Math.max(...graphData.map((d) => d.value));
    const width = 800;
    const height = 300;
    const padding = 40;

    const pathData = graphData.
    map((point, index) => {
      const x = padding + index * (width - 2 * padding) / (graphData.length - 1);
      const y = height - padding - point.value / maxValue * (height - 2 * padding);
      return `${index === 0 ? 'M' : 'L'} ${x} ${y}`;
    }).
    join(' ');

    return (
      <div className="w-full max-w-4xl mx-auto mb-16" data-id="yty6rtmjn" data-path="src/components/StatsCounter.tsx">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-8" data-id="srigfrxzy" data-path="src/components/StatsCounter.tsx">

          <h3 className="text-2xl font-bold text-gray-800 mb-2" data-id="6avyv82o6" data-path="src/components/StatsCounter.tsx">Growth Analytics</h3>
          <p className="text-gray-600" data-id="37zojg8hf" data-path="src/components/StatsCounter.tsx">Our journey of continuous improvement</p>
        </motion.div>

        <Card className="p-6 bg-gradient-to-br from-white to-gray-50 shadow-xl" data-id="woeu5qkk0" data-path="src/components/StatsCounter.tsx">
          <svg width="100%" height="300" viewBox={`0 0 ${width} ${height}`} className="overflow-visible" data-id="6lt6rzsmn" data-path="src/components/StatsCounter.tsx">
            {/* Grid Lines */}
            {[...Array(6)].map((_, i) =>
            <g key={i} data-id="i3dlzqijs" data-path="src/components/StatsCounter.tsx">
                <motion.line
                x1={padding}
                y1={padding + i * (height - 2 * padding) / 5}
                x2={width - padding}
                y2={padding + i * (height - 2 * padding) / 5}
                stroke="#e5e7eb"
                strokeWidth="1"
                strokeDasharray="2,2"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: startAnimation ? 1 : 0 }}
                transition={{ duration: 0.5, delay: i * 0.1 }} data-id="m2j78c28l" data-path="src/components/StatsCounter.tsx" />

              </g>
            )}

            {/* Data Line */}
            <motion.path
              d={pathData}
              fill="none"
              stroke="url(#gradient)"
              strokeWidth="3"
              strokeLinecap="round"
              strokeLinejoin="round"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: startAnimation ? 1 : 0 }}
              transition={{ duration: 2, delay: 0.5, ease: "easeInOut" }} data-id="zhdtd2nbr" data-path="src/components/StatsCounter.tsx" />


            {/* Area Fill */}
            <motion.path
              d={`${pathData} L ${width - padding} ${height - padding} L ${padding} ${height - padding} Z`}
              fill="url(#areaGradient)"
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{
                pathLength: startAnimation ? 1 : 0,
                opacity: startAnimation ? 1 : 0
              }}
              transition={{ duration: 2, delay: 0.8, ease: "easeInOut" }} data-id="ktonmkfwt" data-path="src/components/StatsCounter.tsx" />


            {/* Data Points */}
            {graphData.map((point, index) => {
              const x = padding + index * (width - 2 * padding) / (graphData.length - 1);
              const y = height - padding - point.value / maxValue * (height - 2 * padding);

              return (
                <motion.g key={index} data-id="uvsu3aphv" data-path="src/components/StatsCounter.tsx">
                  <motion.circle
                    cx={x}
                    cy={y}
                    r="6"
                    fill="white"
                    stroke="url(#gradient)"
                    strokeWidth="3"
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{
                      scale: startAnimation ? 1 : 0,
                      opacity: startAnimation ? 1 : 0
                    }}
                    transition={{
                      duration: 0.3,
                      delay: 1 + index * 0.1,
                      type: "spring",
                      stiffness: 200
                    }}
                    whileHover={{ scale: 1.2 }} data-id="vgx24qicm" data-path="src/components/StatsCounter.tsx" />

                  <motion.text
                    x={x}
                    y={height - 10}
                    textAnchor="middle"
                    fontSize="12"
                    fill="#6b7280"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: startAnimation ? 1 : 0 }}
                    transition={{ duration: 0.3, delay: 1.2 + index * 0.1 }} data-id="5xfim4etz" data-path="src/components/StatsCounter.tsx">

                    {point.month}
                  </motion.text>
                </motion.g>);

            })}

            {/* Gradients */}
            <defs data-id="zvdngcodf" data-path="src/components/StatsCounter.tsx">
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%" data-id="8zc77tffr" data-path="src/components/StatsCounter.tsx">
                <stop offset="0%" stopColor="#8b5cf6" data-id="6lh946lu3" data-path="src/components/StatsCounter.tsx" />
                <stop offset="50%" stopColor="#ec4899" data-id="wdsph0e5i" data-path="src/components/StatsCounter.tsx" />
                <stop offset="100%" stopColor="#06b6d4" data-id="66njfqhsv" data-path="src/components/StatsCounter.tsx" />
              </linearGradient>
              <linearGradient id="areaGradient" x1="0%" y1="0%" x2="0%" y2="100%" data-id="e995644xk" data-path="src/components/StatsCounter.tsx">
                <stop offset="0%" stopColor="#8b5cf6" stopOpacity="0.3" data-id="87pp57if0" data-path="src/components/StatsCounter.tsx" />
                <stop offset="100%" stopColor="#8b5cf6" stopOpacity="0.05" data-id="evdw14sd4" data-path="src/components/StatsCounter.tsx" />
              </linearGradient>
            </defs>
          </svg>
        </Card>
      </div>);

  };

  return (
    <section ref={ref} className="py-24 bg-gradient-to-br from-slate-50 via-white to-blue-50" data-id="emck0pp5h" data-path="src/components/StatsCounter.tsx">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-id="meszfyupa" data-path="src/components/StatsCounter.tsx">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16" data-id="5kgsegpjz" data-path="src/components/StatsCounter.tsx">

          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6" data-id="tt5v5mtwk" data-path="src/components/StatsCounter.tsx">
            Trusted by
            <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent" data-id="695i2x5cs" data-path="src/components/StatsCounter.tsx"> Millions</span>
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto" data-id="91wtjldq8" data-path="src/components/StatsCounter.tsx">
            Join the growing community of users who trust our platform for their success. 
            Here are the numbers that speak for themselves.
          </p>
        </motion.div>

        {/* Animated SVG Graph */}
        <AnimatedGraph data-id="cnhi1ep9t" data-path="src/components/StatsCounter.tsx" />

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" data-id="5jaqrowsc" data-path="src/components/StatsCounter.tsx">
          {stats.map((stat, index) =>
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            whileInView={{ opacity: 1, y: 0, scale: 1 }}
            viewport={{ once: true }}
            transition={{
              duration: 0.6,
              delay: stat.delay,
              type: "spring",
              stiffness: 100
            }}
            whileHover={{
              y: -10,
              transition: { duration: 0.3 }
            }} data-id="e3zf5llzv" data-path="src/components/StatsCounter.tsx">

              <Card className="h-full p-6 border-0 shadow-lg hover:shadow-2xl transition-all duration-500 bg-white/80 backdrop-blur-sm group overflow-hidden" data-id="lmgrvk8m9" data-path="src/components/StatsCounter.tsx">
                {/* Background Gradient */}
                <div className={`absolute inset-0 bg-gradient-to-br ${stat.color} opacity-0 group-hover:opacity-5 transition-opacity duration-500`} data-id="3az2agixg" data-path="src/components/StatsCounter.tsx" />
                
                <CardContent className="p-0 text-center relative z-10" data-id="mist7f4bs" data-path="src/components/StatsCounter.tsx">
                  {/* Icon */}
                  <motion.div
                  whileHover={{
                    scale: 1.2,
                    rotate: 15
                  }}
                  transition={{ duration: 0.3 }}
                  className={`w-16 h-16 mx-auto mb-6 rounded-2xl bg-gradient-to-br ${stat.color} p-4 shadow-lg`} data-id="90i8j82dc" data-path="src/components/StatsCounter.tsx">

                    <stat.icon className="w-full h-full text-white" data-id="sucl7xtep" data-path="src/components/StatsCounter.tsx" />
                  </motion.div>

                  {/* Counter */}
                  <div className="mb-2" data-id="gsu4winbs" data-path="src/components/StatsCounter.tsx">
                    {startAnimation &&
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{
                      duration: 0.5,
                      delay: stat.delay + 0.2,
                      type: "spring",
                      stiffness: 200
                    }}
                    className="text-4xl md:text-5xl font-bold text-gray-900" data-id="94r6jo2m8" data-path="src/components/StatsCounter.tsx">

                        <CountUp
                      start={0}
                      end={stat.value}
                      duration={2.5}
                      delay={stat.delay + 0.5}
                      decimals={stat.value % 1 !== 0 ? 1 : 0} data-id="k01tgoi9j" data-path="src/components/StatsCounter.tsx" />

                        <span className={`bg-gradient-to-r ${stat.color} bg-clip-text text-transparent`} data-id="vckv37u9y" data-path="src/components/StatsCounter.tsx">
                          {stat.suffix}
                        </span>
                      </motion.div>
                  }
                  </div>

                  {/* Label */}
                  <h3 className="text-xl font-semibold text-gray-800 mb-2 group-hover:text-gray-900 transition-colors" data-id="xoodyd2zv" data-path="src/components/StatsCounter.tsx">
                    {stat.label}
                  </h3>

                  {/* Description */}
                  <p className="text-gray-600 group-hover:text-gray-700 transition-colors" data-id="2cqavnynq" data-path="src/components/StatsCounter.tsx">
                    {stat.description}
                  </p>

                  {/* Progress Bar */}
                  <motion.div
                  className={`h-1 bg-gradient-to-r ${stat.color} mt-6 rounded-full`}
                  initial={{ width: 0 }}
                  whileInView={{ width: '100%' }}
                  viewport={{ once: true }}
                  transition={{
                    delay: stat.delay + 1,
                    duration: 1.5,
                    ease: "easeOut"
                  }} data-id="h2mv4ug54" data-path="src/components/StatsCounter.tsx" />

                </CardContent>

                {/* Floating Elements */}
                <motion.div
                className={`absolute top-4 right-4 w-3 h-3 rounded-full bg-gradient-to-r ${stat.color} opacity-0 group-hover:opacity-60`}
                animate={{
                  y: [0, -15, 0],
                  opacity: [0.6, 1, 0.6]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: index * 0.5
                }} data-id="7p1u8xghp" data-path="src/components/StatsCounter.tsx" />

              </Card>
            </motion.div>
          )}
        </div>
      </div>
    </section>);

};

export default StatsCounter;