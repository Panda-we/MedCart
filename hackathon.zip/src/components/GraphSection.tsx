import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell } from
'recharts';
import { TrendingUp, Users, ShoppingCart, Activity } from 'lucide-react';

const GraphSection: React.FC = () => {
  const salesData = [
  { month: 'Jan', sales: 45000, orders: 1200, customers: 890 },
  { month: 'Feb', sales: 52000, orders: 1450, customers: 1020 },
  { month: 'Mar', sales: 48000, orders: 1320, customers: 950 },
  { month: 'Apr', sales: 61000, orders: 1680, customers: 1180 },
  { month: 'May', sales: 71000, orders: 1920, customers: 1350 },
  { month: 'Jun', sales: 68000, orders: 1850, customers: 1290 },
  { month: 'Jul', sales: 78000, orders: 2100, customers: 1480 },
  { month: 'Aug', sales: 82000, orders: 2250, customers: 1580 },
  { month: 'Sep', sales: 85000, orders: 2350, customers: 1650 },
  { month: 'Oct', sales: 89000, orders: 2450, customers: 1720 },
  { month: 'Nov', sales: 94000, orders: 2600, customers: 1850 },
  { month: 'Dec', sales: 102000, orders: 2800, customers: 1980 }];


  const categoryData = [
  { name: 'Diagnostics', value: 35, color: '#10B981' },
  { name: 'Monitoring', value: 25, color: '#3B82F6' },
  { name: 'Safety Equipment', value: 20, color: '#8B5CF6' },
  { name: 'Supplies', value: 12, color: '#F59E0B' },
  { name: 'Others', value: 8, color: '#EF4444' }];


  const performanceData = [
  { metric: 'Customer Satisfaction', value: 98 },
  { metric: 'Delivery Success', value: 99 },
  { metric: 'Product Quality', value: 97 },
  { metric: 'Support Response', value: 95 }];


  const stats = [
  {
    icon: TrendingUp,
    title: 'Monthly Growth',
    value: '+24%',
    description: 'Compared to last month',
    color: 'emerald'
  },
  {
    icon: Users,
    title: 'Active Customers',
    value: '15.2K',
    description: 'Healthcare professionals',
    color: 'blue'
  },
  {
    icon: ShoppingCart,
    title: 'Total Orders',
    value: '28.5K',
    description: 'This year',
    color: 'purple'
  },
  {
    icon: Activity,
    title: 'System Uptime',
    value: '99.9%',
    description: 'Last 30 days',
    color: 'orange'
  }];


  return (
    <section className="py-24 bg-black" data-id="pdptfxx13" data-path="src/components/GraphSection.tsx">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-id="gufmi90ok" data-path="src/components/GraphSection.tsx">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16" data-id="bdxrxlpq1" data-path="src/components/GraphSection.tsx">

          <div className="flex items-center justify-center mb-4" data-id="72xtvao46" data-path="src/components/GraphSection.tsx">
            <Activity className="h-6 w-6 text-emerald-400 mr-2" data-id="5uvki4f48" data-path="src/components/GraphSection.tsx" />
            <span className="text-emerald-400 font-semibold" data-id="gk95g4ddl" data-path="src/components/GraphSection.tsx">Performance Analytics</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6" data-id="0mq7aguoi" data-path="src/components/GraphSection.tsx">
            MedCart Analytics Dashboard
          </h2>
          <p className="text-xl text-gray-400 max-w-3xl mx-auto" data-id="alpdzu0bg" data-path="src/components/GraphSection.tsx">
            Real-time insights into our platform performance, customer satisfaction, 
            and business growth metrics.
          </p>
        </motion.div>

        {/* Stats Overview */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.2, duration: 0.6 }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12" data-id="6wd2c5k7d" data-path="src/components/GraphSection.tsx">

          {stats.map((stat, index) =>
          <Card key={index} className="bg-gray-800/50 border-gray-700 hover:border-emerald-400/50 transition-all duration-300" data-id="7om7srn3s" data-path="src/components/GraphSection.tsx">
              <CardContent className="p-6" data-id="76q4mpu9e" data-path="src/components/GraphSection.tsx">
                <div className="flex items-center justify-between mb-4" data-id="34lwe730o" data-path="src/components/GraphSection.tsx">
                  <stat.icon className={`h-8 w-8 text-${stat.color}-400`} data-id="u3jgtyn4e" data-path="src/components/GraphSection.tsx" />
                  <span className={`text-2xl font-bold text-${stat.color}-400`} data-id="vxql8e15r" data-path="src/components/GraphSection.tsx">
                    {stat.value}
                  </span>
                </div>
                <h3 className="font-semibold text-white mb-1" data-id="8gf2du4p5" data-path="src/components/GraphSection.tsx">{stat.title}</h3>
                <p className="text-sm text-gray-400" data-id="opzyfah3d" data-path="src/components/GraphSection.tsx">{stat.description}</p>
              </CardContent>
            </Card>
          )}
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-8 mb-12" data-id="864z2zgaq" data-path="src/components/GraphSection.tsx">
          {/* Sales Chart */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }} data-id="gys76njhk" data-path="src/components/GraphSection.tsx">

            <Card className="bg-gray-800/50 border-gray-700" data-id="q66qm6dwm" data-path="src/components/GraphSection.tsx">
              <CardContent className="p-6" data-id="xo6eb67u0" data-path="src/components/GraphSection.tsx">
                <h3 className="text-xl font-semibold text-white mb-6" data-id="6nds0aaoj" data-path="src/components/GraphSection.tsx">
                  Sales Performance
                </h3>
                <ResponsiveContainer width="100%" height={300} data-id="q1389jspl" data-path="src/components/GraphSection.tsx">
                  <LineChart data={salesData} data-id="dz5w2vuts" data-path="src/components/GraphSection.tsx">
                    <CartesianGrid strokeDasharray="3 3" stroke="#374151" data-id="rzw6hn72i" data-path="src/components/GraphSection.tsx" />
                    <XAxis dataKey="month" stroke="#9CA3AF" data-id="3ksrm7kq6" data-path="src/components/GraphSection.tsx" />
                    <YAxis stroke="#9CA3AF" data-id="lbkn1htla" data-path="src/components/GraphSection.tsx" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '8px',
                        color: '#fff'
                      }} data-id="nh7payr3k" data-path="src/components/GraphSection.tsx" />

                    <Line
                      type="monotone"
                      dataKey="sales"
                      stroke="#10B981"
                      strokeWidth={3}
                      dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }} data-id="tidyhx7ox" data-path="src/components/GraphSection.tsx" />

                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>

          {/* Category Distribution */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }} data-id="xm3uyt6nm" data-path="src/components/GraphSection.tsx">

            <Card className="bg-gray-800/50 border-gray-700" data-id="jot8fhti3" data-path="src/components/GraphSection.tsx">
              <CardContent className="p-6" data-id="63id4cfbn" data-path="src/components/GraphSection.tsx">
                <h3 className="text-xl font-semibold text-white mb-6" data-id="z7t59kwd0" data-path="src/components/GraphSection.tsx">
                  Product Categories
                </h3>
                <ResponsiveContainer width="100%" height={300} data-id="fymvaax11" data-path="src/components/GraphSection.tsx">
                  <PieChart data-id="ny521hqqd" data-path="src/components/GraphSection.tsx">
                    <Pie
                      data={categoryData}
                      cx="50%"
                      cy="50%"
                      outerRadius={100}
                      dataKey="value"
                      label={({ name, value }) => `${name}: ${value}%`}
                      labelLine={false} data-id="o7xlf8i68" data-path="src/components/GraphSection.tsx">

                      {categoryData.map((entry, index) =>
                      <Cell key={`cell-${index}`} fill={entry.color} data-id="68prb0h20" data-path="src/components/GraphSection.tsx" />
                      )}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#1F2937',
                        border: '1px solid #374151',
                        borderRadius: '8px',
                        color: '#fff'
                      }} data-id="zbaxlhr4o" data-path="src/components/GraphSection.tsx" />

                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </motion.div>
        </div>

        {/* Performance Metrics */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4, duration: 0.6 }} data-id="9w4vab6hx" data-path="src/components/GraphSection.tsx">

          <Card className="bg-gray-800/50 border-gray-700" data-id="rmqax5abs" data-path="src/components/GraphSection.tsx">
            <CardContent className="p-6" data-id="cme6rt9a1" data-path="src/components/GraphSection.tsx">
              <h3 className="text-xl font-semibold text-white mb-6" data-id="m8m2hc5th" data-path="src/components/GraphSection.tsx">
                Performance Metrics
              </h3>
              <ResponsiveContainer width="100%" height={300} data-id="2oi815rch" data-path="src/components/GraphSection.tsx">
                <BarChart data={performanceData} data-id="zxwdmaa27" data-path="src/components/GraphSection.tsx">
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" data-id="5c54f0q9m" data-path="src/components/GraphSection.tsx" />
                  <XAxis dataKey="metric" stroke="#9CA3AF" data-id="8pdfg3hn3" data-path="src/components/GraphSection.tsx" />
                  <YAxis stroke="#9CA3AF" data-id="00426m2lp" data-path="src/components/GraphSection.tsx" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#1F2937',
                      border: '1px solid #374151',
                      borderRadius: '8px',
                      color: '#fff'
                    }} data-id="uvta5dg72" data-path="src/components/GraphSection.tsx" />

                  <Bar
                    dataKey="value"
                    fill="#10B981"
                    radius={[4, 4, 0, 0]} data-id="ezlyp9gf0" data-path="src/components/GraphSection.tsx" />

                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        {/* Growth Indicators */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ delay: 0.6, duration: 0.6 }}
          className="mt-12 text-center" data-id="b8orcc9bu" data-path="src/components/GraphSection.tsx">

          <div className="inline-flex items-center space-x-8 bg-emerald-400/10 rounded-full px-8 py-4 border border-emerald-400/20" data-id="vbk16es0a" data-path="src/components/GraphSection.tsx">
            <div className="flex items-center space-x-2" data-id="cjxdy934y" data-path="src/components/GraphSection.tsx">
              <div className="w-3 h-3 bg-emerald-400 rounded-full animate-pulse" data-id="p0s1jb7pc" data-path="src/components/GraphSection.tsx" />
              <span className="text-emerald-400 font-semibold" data-id="xhrvx4grl" data-path="src/components/GraphSection.tsx">Real-time Data</span>
            </div>
            <div className="flex items-center space-x-2" data-id="8s73vcy5q" data-path="src/components/GraphSection.tsx">
              <TrendingUp className="h-4 w-4 text-emerald-400" data-id="f1zbz4ype" data-path="src/components/GraphSection.tsx" />
              <span className="text-emerald-400 font-semibold" data-id="4w9njsdsm" data-path="src/components/GraphSection.tsx">Growing Fast</span>
            </div>
            <div className="flex items-center space-x-2" data-id="7hj5haa2m" data-path="src/components/GraphSection.tsx">
              <Activity className="h-4 w-4 text-emerald-400" data-id="sfaor6zfy" data-path="src/components/GraphSection.tsx" />
              <span className="text-emerald-400 font-semibold" data-id="641xmhnbj" data-path="src/components/GraphSection.tsx">24/7 Monitoring</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>);

};

export default GraphSection;