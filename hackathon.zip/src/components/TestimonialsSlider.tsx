import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, Star, Quote } from 'lucide-react';

const TestimonialsSlider = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [direction, setDirection] = useState(0);

  const testimonials = [
  {
    name: "Sarah Johnson",
    title: "CEO, TechStart Inc.",
    image: "https://images.unsplash.com/photo-1494790108755-2616b332c495?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
    content: "This platform has completely transformed how we manage our projects. The intuitive interface and powerful features have increased our team's productivity by 300%. It's simply revolutionary!",
    rating: 5,
    company: "TechStart Inc.",
    gradient: "from-purple-500 to-pink-500"
  },
  {
    name: "Michael Chen",
    title: "CTO, Innovation Labs",
    image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
    content: "The analytics and insights provided are game-changing. We've been able to make data-driven decisions that resulted in 40% revenue growth in just 6 months. Highly recommended!",
    rating: 5,
    company: "Innovation Labs",
    gradient: "from-blue-500 to-teal-500"
  },
  {
    name: "Emily Rodriguez",
    title: "Design Director, Creative Studio",
    image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
    content: "As a designer, I appreciate beautiful and functional tools. This platform delivers both. The user experience is flawless, and the design system is incredibly well thought out.",
    rating: 5,
    company: "Creative Studio",
    gradient: "from-green-500 to-emerald-500"
  },
  {
    name: "David Thompson",
    title: "Founder, StartupHub",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
    content: "We've tried countless solutions, but nothing comes close to this platform's capabilities. The customer support is exceptional, and the feature set is exactly what growing companies need.",
    rating: 5,
    company: "StartupHub",
    gradient: "from-orange-500 to-red-500"
  },
  {
    name: "Lisa Wang",
    title: "VP of Operations, ScaleUp Co.",
    image: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=150&q=80",
    content: "The automation features have saved us countless hours every week. What used to take our team days now happens automatically. It's like having an extra team member that never sleeps.",
    rating: 5,
    company: "ScaleUp Co.",
    gradient: "from-violet-500 to-purple-500"
  }];


  useEffect(() => {
    const timer = setInterval(() => {
      setDirection(1);
      setCurrentIndex((prev) => (prev + 1) % testimonials.length);
    }, 5000);

    return () => clearInterval(timer);
  }, [testimonials.length]);

  const goToSlide = (index: number) => {
    if (index > currentIndex) {
      setDirection(1);
    } else if (index < currentIndex) {
      setDirection(-1);
    }
    setCurrentIndex(index);
  };

  const nextSlide = () => {
    setDirection(1);
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevSlide = () => {
    setDirection(-1);
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  const slideVariants = {
    enter: (direction: number) => ({
      x: direction > 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.8,
      rotateY: direction > 0 ? 15 : -15
    }),
    center: {
      zIndex: 1,
      x: 0,
      opacity: 1,
      scale: 1,
      rotateY: 0
    },
    exit: (direction: number) => ({
      zIndex: 0,
      x: direction < 0 ? 1000 : -1000,
      opacity: 0,
      scale: 0.8,
      rotateY: direction < 0 ? 15 : -15
    })
  };

  const swipeConfidenceThreshold = 10000;
  const swipePower = (offset: number, velocity: number) => {
    return Math.abs(offset) * velocity;
  };

  return (
    <section className="py-24 bg-gradient-to-br from-gray-900 via-blue-900 to-purple-900 overflow-hidden" data-id="ksaul2hev" data-path="src/components/TestimonialsSlider.tsx">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8" data-id="qrhze938u" data-path="src/components/TestimonialsSlider.tsx">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16" data-id="rvmi7m6zs" data-path="src/components/TestimonialsSlider.tsx">

          <h2 className="text-4xl md:text-5xl font-bold text-white mb-6" data-id="qvbwxiki4" data-path="src/components/TestimonialsSlider.tsx">
            What Our
            <span className="bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent" data-id="8082cu7ag" data-path="src/components/TestimonialsSlider.tsx"> Customers Say</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto" data-id="epcm5j2hy" data-path="src/components/TestimonialsSlider.tsx">
            Don't just take our word for it. Here's what industry leaders and innovators 
            have to say about their experience with our platform.
          </p>
        </motion.div>

        <div className="relative max-w-4xl mx-auto" data-id="frkw2nbkq" data-path="src/components/TestimonialsSlider.tsx">
          {/* Main Testimonial Display */}
          <div className="relative h-[500px] flex items-center justify-center" data-id="whnxbxr0o" data-path="src/components/TestimonialsSlider.tsx">
            <AnimatePresence initial={false} custom={direction} mode="wait" data-id="16zuz192w" data-path="src/components/TestimonialsSlider.tsx">
              <motion.div
                key={currentIndex}
                custom={direction}
                variants={slideVariants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{
                  x: { type: "spring", stiffness: 300, damping: 30 },
                  opacity: { duration: 0.4 },
                  scale: { duration: 0.4 },
                  rotateY: { duration: 0.4 }
                }}
                drag="x"
                dragConstraints={{ left: 0, right: 0 }}
                dragElastic={1}
                onDragEnd={(e, { offset, velocity }) => {
                  const swipe = swipePower(offset.x, velocity.x);

                  if (swipe < -swipeConfidenceThreshold) {
                    nextSlide();
                  } else if (swipe > swipeConfidenceThreshold) {
                    prevSlide();
                  }
                }}
                className="absolute w-full cursor-grab active:cursor-grabbing" data-id="fmoreahzn" data-path="src/components/TestimonialsSlider.tsx">

                <Card className="mx-auto max-w-3xl border-0 shadow-2xl bg-white/10 backdrop-blur-md" data-id="4bwoznit2" data-path="src/components/TestimonialsSlider.tsx">
                  <CardContent className="p-8 md:p-12" data-id="8ezfqlj09" data-path="src/components/TestimonialsSlider.tsx">
                    {/* Quote Icon */}
                    <motion.div
                      initial={{ scale: 0, rotate: -180 }}
                      animate={{ scale: 1, rotate: 0 }}
                      transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                      className={`w-16 h-16 mx-auto mb-8 rounded-full bg-gradient-to-br ${testimonials[currentIndex].gradient} p-4 shadow-lg`} data-id="ptss88u9o" data-path="src/components/TestimonialsSlider.tsx">

                      <Quote className="w-full h-full text-white" data-id="x4iwffvz4" data-path="src/components/TestimonialsSlider.tsx" />
                    </motion.div>

                    {/* Stars */}
                    <motion.div
                      className="flex justify-center mb-6"
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.3, duration: 0.5 }} data-id="hrsyui98n" data-path="src/components/TestimonialsSlider.tsx">

                      {[...Array(testimonials[currentIndex].rating)].map((_, i) =>
                      <motion.div
                        key={i}
                        initial={{ scale: 0, rotate: -180 }}
                        animate={{ scale: 1, rotate: 0 }}
                        transition={{
                          delay: 0.4 + i * 0.1,
                          type: "spring",
                          stiffness: 200
                        }} data-id="vnnf5fo3e" data-path="src/components/TestimonialsSlider.tsx">

                          <Star className="w-6 h-6 text-yellow-400 fill-current mx-1" data-id="4nb5idbjd" data-path="src/components/TestimonialsSlider.tsx" />
                        </motion.div>
                      )}
                    </motion.div>

                    {/* Testimonial Content */}
                    <motion.blockquote
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4, duration: 0.6 }}
                      className="text-xl md:text-2xl text-white/90 font-light leading-relaxed text-center mb-8" data-id="t2kumj9bh" data-path="src/components/TestimonialsSlider.tsx">

                      "{testimonials[currentIndex].content}"
                    </motion.blockquote>

                    {/* Author Info */}
                    <motion.div
                      initial={{ opacity: 0, y: 30 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5, duration: 0.6 }}
                      className="flex items-center justify-center" data-id="3cwqsp3od" data-path="src/components/TestimonialsSlider.tsx">

                      <motion.img
                        whileHover={{ scale: 1.1 }}
                        src={testimonials[currentIndex].image}
                        alt={testimonials[currentIndex].name}
                        className="w-16 h-16 rounded-full border-4 border-white/20 shadow-lg mr-4" data-id="ggxmb9eom" data-path="src/components/TestimonialsSlider.tsx" />

                      <div className="text-center" data-id="33m4n3ofg" data-path="src/components/TestimonialsSlider.tsx">
                        <h4 className="text-lg font-semibold text-white" data-id="3hgxwfbc8" data-path="src/components/TestimonialsSlider.tsx">
                          {testimonials[currentIndex].name}
                        </h4>
                        <p className="text-gray-300" data-id="8hvijo49i" data-path="src/components/TestimonialsSlider.tsx">
                          {testimonials[currentIndex].title}
                        </p>
                        <p className={`text-sm bg-gradient-to-r ${testimonials[currentIndex].gradient} bg-clip-text text-transparent font-medium`} data-id="51o95vo9o" data-path="src/components/TestimonialsSlider.tsx">
                          {testimonials[currentIndex].company}
                        </p>
                      </div>
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Navigation Buttons */}
          <div className="absolute top-1/2 -translate-y-1/2 left-4 z-10" data-id="3zhojqbrw" data-path="src/components/TestimonialsSlider.tsx">
            <Button
              variant="outline"
              size="icon"
              onClick={prevSlide}
              className="bg-white/10 border-white/20 text-white hover:bg-white/20 backdrop-blur-sm" data-id="suc7rcgvb" data-path="src/components/TestimonialsSlider.tsx">

              <ChevronLeft className="w-5 h-5" data-id="imviwkyva" data-path="src/components/TestimonialsSlider.tsx" />
            </Button>
          </div>
          
          <div className="absolute top-1/2 -translate-y-1/2 right-4 z-10" data-id="3z7xteacr" data-path="src/components/TestimonialsSlider.tsx">
            <Button
              variant="outline"
              size="icon"
              onClick={nextSlide}
              className="bg-white/10 border-white/20 text-white hover:bg-white/20 backdrop-blur-sm" data-id="0a3i2ulhs" data-path="src/components/TestimonialsSlider.tsx">

              <ChevronRight className="w-5 h-5" data-id="h364afgz3" data-path="src/components/TestimonialsSlider.tsx" />
            </Button>
          </div>

          {/* Dots Indicator */}
          <div className="flex justify-center mt-8 gap-3" data-id="25zdokroc" data-path="src/components/TestimonialsSlider.tsx">
            {testimonials.map((_, index) =>
            <motion.button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentIndex ?
              'bg-white scale-125 shadow-lg' :
              'bg-white/30 hover:bg-white/60'}`
              }
              whileHover={{ scale: 1.2 }}
              whileTap={{ scale: 0.9 }} data-id="pfts8q61m" data-path="src/components/TestimonialsSlider.tsx" />

            )}
          </div>

          {/* Thumbnail Preview */}
          <motion.div
            className="flex justify-center mt-8 gap-4 overflow-hidden"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.6 }} data-id="l83dqecbe" data-path="src/components/TestimonialsSlider.tsx">

            {testimonials.map((testimonial, index) =>
            <motion.button
              key={index}
              onClick={() => goToSlide(index)}
              className={`relative p-1 rounded-full transition-all duration-300 ${
              index === currentIndex ?
              'ring-2 ring-white shadow-lg scale-110' :
              'ring-1 ring-white/30 hover:ring-white/60 opacity-60 hover:opacity-100'}`
              }
              whileHover={{ scale: index === currentIndex ? 1.1 : 1.05 }}
              whileTap={{ scale: 0.95 }} data-id="omn5qpmuq" data-path="src/components/TestimonialsSlider.tsx">

                <img
                src={testimonial.image}
                alt={testimonial.name}
                className="w-12 h-12 rounded-full object-cover" data-id="sh2g5t86r" data-path="src/components/TestimonialsSlider.tsx" />

              </motion.button>
            )}
          </motion.div>
        </div>

        {/* Background Decorations */}
        <motion.div
          className="absolute top-20 left-10 w-32 h-32 rounded-full bg-gradient-to-r from-blue-400/20 to-purple-400/20 blur-xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.6, 0.3]
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }} data-id="h0pgflwjp" data-path="src/components/TestimonialsSlider.tsx" />

        
        <motion.div
          className="absolute bottom-20 right-10 w-24 h-24 rounded-full bg-gradient-to-r from-pink-400/20 to-blue-400/20 blur-xl"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.6, 0.3, 0.6]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: "easeInOut"
          }} data-id="fenpj8kmv" data-path="src/components/TestimonialsSlider.tsx" />

      </div>
    </section>);

};

export default TestimonialsSlider;