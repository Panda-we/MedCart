import React, { useEffect, useRef, useState } from 'react';
import { gsap } from 'gsap';

interface WaterWaveBackgroundProps {
  children?: React.ReactNode;
  className?: string;
  showImages?: boolean;
}

const WaterWaveBackground: React.FC<WaterWaveBackgroundProps> = ({
  children,
  className = '',
  showImages = true
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const wave1Ref = useRef<SVGPathElement>(null);
  const wave2Ref = useRef<SVGPathElement>(null);
  const wave3Ref = useRef<SVGPathElement>(null);
  const wave4Ref = useRef<SVGPathElement>(null); // Additional wave
  const floatingImagesRef = useRef<HTMLDivElement[]>([]);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const timelineRef = useRef<gsap.core.Timeline>();

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    // Mouse tracking for interactive effects
    const handleMouseMove = (e: MouseEvent) => {
      const rect = container.getBoundingClientRect();
      setMousePosition({
        x: (e.clientX - rect.left) / rect.width * 100,
        y: (e.clientY - rect.top) / rect.height * 100
      });
    };

    container.addEventListener('mousemove', handleMouseMove);

    // Create enhanced timeline for wave animations
    const tl = gsap.timeline({ repeat: -1 });
    timelineRef.current = tl;

    // Enhanced wave animations with cursor interaction
    if (wave1Ref.current) {
      tl.to(wave1Ref.current, {
        duration: 8,
        ease: "sine.inOut",
        attr: {
          d: "M0,100 Q150,120 300,100 T600,100 T900,100 T1200,100 T1500,100 T1800,100 L1800,200 L0,200 Z"
        }
      }).
      to(wave1Ref.current, {
        duration: 8,
        ease: "sine.inOut",
        attr: {
          d: "M0,100 Q150,80 300,100 T600,100 T900,100 T1200,100 T1500,100 T1800,100 L1800,200 L0,200 Z"
        }
      }, 0);
    }

    if (wave2Ref.current) {
      tl.to(wave2Ref.current, {
        duration: 6,
        ease: "sine.inOut",
        attr: {
          d: "M0,120 Q200,140 400,120 T800,120 T1200,120 T1600,120 T2000,120 L2000,200 L0,200 Z"
        }
      }).
      to(wave2Ref.current, {
        duration: 6,
        ease: "sine.inOut",
        attr: {
          d: "M0,120 Q200,100 400,120 T800,120 T1200,120 T1600,120 T2000,120 L2000,200 L0,200 Z"
        }
      }, 0);
    }

    if (wave3Ref.current) {
      tl.to(wave3Ref.current, {
        duration: 10,
        ease: "sine.inOut",
        attr: {
          d: "M0,140 Q250,160 500,140 T1000,140 T1500,140 T2000,140 L2000,200 L0,200 Z"
        }
      }).
      to(wave3Ref.current, {
        duration: 10,
        ease: "sine.inOut",
        attr: {
          d: "M0,140 Q250,120 500,140 T1000,140 T1500,140 T2000,140 L2000,200 L0,200 Z"
        }
      }, 0);
    }

    // Additional wave layer for more depth
    if (wave4Ref.current) {
      tl.to(wave4Ref.current, {
        duration: 12,
        ease: "sine.inOut",
        attr: {
          d: "M0,160 Q300,180 600,160 T1200,160 T1800,160 L1800,200 L0,200 Z"
        }
      }).
      to(wave4Ref.current, {
        duration: 12,
        ease: "sine.inOut",
        attr: {
          d: "M0,160 Q300,140 600,160 T1200,160 T1800,160 L1800,200 L0,200 Z"
        }
      }, 0);
    }

    // Enhanced floating images with more dynamic movement
    floatingImagesRef.current.forEach((img, index) => {
      if (img) {
        gsap.to(img, {
          duration: 4 + index * 0.8,
          y: "+=30",
          x: "+=15",
          rotation: "+=10",
          ease: "sine.inOut",
          repeat: -1,
          yoyo: true,
          delay: index * 0.5
        });
      }
    });

    return () => {
      container.removeEventListener('mousemove', handleMouseMove);
      tl.kill();
    };
  }, []);

  // Dynamic wave distortion based on mouse position
  useEffect(() => {
    if (timelineRef.current && wave1Ref.current) {
      const distortionFactor = (mousePosition.x - 50) * 0.5;
      gsap.to(wave1Ref.current, {
        duration: 0.5,
        ease: "power2.out",
        attr: {
          d: `M0,${100 + distortionFactor * 0.2} Q150,${120 + distortionFactor} 300,${100 + distortionFactor * 0.3} T600,${100 + distortionFactor * 0.1} T900,100 T1200,100 T1500,100 T1800,100 L1800,200 L0,200 Z`
        }
      });
    }
  }, [mousePosition]);

  const addToFloatingRefs = (el: HTMLDivElement | null) => {
    if (el && !floatingImagesRef.current.includes(el)) {
      floatingImagesRef.current.push(el);
    }
  };

  const oceanImages = [
  {
    src: "https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=100&h=100&fit=crop&crop=center",
    alt: "Coral Reef",
    className: "absolute top-20 left-20 w-16 h-16 opacity-40"
  },
  {
    src: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=100&h=100&fit=crop&crop=center",
    alt: "Tropical Fish",
    className: "absolute top-40 right-32 w-20 h-20 opacity-35"
  },
  {
    src: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=100&h=100&fit=crop&crop=center",
    alt: "Sea Turtle",
    className: "absolute bottom-40 left-1/4 w-18 h-18 opacity-45"
  },
  {
    src: "https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=100&h=100&fit=crop&crop=center",
    alt: "Seahorse",
    className: "absolute top-60 left-1/2 w-14 h-14 opacity-38"
  },
  {
    src: "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=100&h=100&fit=crop&crop=center",
    alt: "Jellyfish",
    className: "absolute bottom-60 right-20 w-16 h-16 opacity-42"
  },
  {
    src: "https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=100&h=100&fit=crop&crop=center",
    alt: "Ocean Bubbles",
    className: "absolute top-32 right-1/4 w-12 h-12 opacity-35"
  },
  {
    src: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=100&h=100&fit=crop&crop=center",
    alt: "Starfish",
    className: "absolute bottom-32 left-1/3 w-15 h-15 opacity-40"
  }];


  return (
    <div ref={containerRef} className={`relative overflow-hidden ${className}`} data-id="1gggc6rrd" data-path="src/components/WaterWaveBackground.tsx">
      {/* Enhanced background with dynamic gradient */}
      <div
        className="absolute inset-0 transition-all duration-1000 ease-out"
        style={{
          background: `
            radial-gradient(circle at ${mousePosition.x}% ${mousePosition.y}%, 
              rgba(59, 130, 246, 0.3) 0%, 
              rgba(99, 102, 241, 0.2) 25%, 
              transparent 50%),
            linear-gradient(135deg, 
              #3b82f6 0%, 
              #1e40af 25%, 
              #1e3a8a 50%, 
              #1e40af 75%, 
              #3b82f6 100%)
          `
        }} data-id="wnsaatoi5" data-path="src/components/WaterWaveBackground.tsx" />

      
      {/* Enhanced floating images */}
      {showImages &&
      <div className="absolute inset-0 pointer-events-none" data-id="cee48zfvb" data-path="src/components/WaterWaveBackground.tsx">
          {oceanImages.map((image, index) =>
        <div
          key={index}
          ref={addToFloatingRefs}
          className={`${image.className} hover-water transition-all duration-300`}
          style={{
            transform: `translate(${(mousePosition.x - 50) * 0.1}px, ${(mousePosition.y - 50) * 0.1}px)`
          }} data-id="v2v75xd2l" data-path="src/components/WaterWaveBackground.tsx">
              <img
            src={image.src}
            alt={image.alt}
            className="w-full h-full rounded-full object-cover filter drop-shadow-lg hover-glow"
            style={{
              boxShadow: '0 4px 20px rgba(59, 130, 246, 0.3)'
            }} data-id="n5xytpfv4" data-path="src/components/WaterWaveBackground.tsx" />

            </div>
        )}
        </div>
      }

      {/* Enhanced animated waves with interactive ocean lines */}
      <div className="absolute bottom-0 left-0 w-full h-full" data-id="szqjsy753" data-path="src/components/WaterWaveBackground.tsx">
        <svg
          className="absolute bottom-0 w-full h-full"
          viewBox="0 0 1800 200"
          preserveAspectRatio="none" data-id="c5wycyyck" data-path="src/components/WaterWaveBackground.tsx">

          {/* Wave 4 - Deepest layer */}
          <path
            ref={wave4Ref}
            d="M0,160 Q300,160 600,160 T1200,160 T1800,160 L1800,200 L0,200 Z"
            fill="rgba(29, 78, 216, 0.2)"
            className="drop-shadow-sm" data-id="67rntvac0" data-path="src/components/WaterWaveBackground.tsx" />

          
          {/* Wave 3 - Back layer */}
          <path
            ref={wave3Ref}
            d="M0,140 Q250,140 500,140 T1000,140 T1500,140 T2000,140 L2000,200 L0,200 Z"
            fill="rgba(29, 78, 216, 0.3)"
            className="drop-shadow-sm" data-id="u2w38a5l7" data-path="src/components/WaterWaveBackground.tsx" />

          
          {/* Wave 2 - Middle layer */}
          <path
            ref={wave2Ref}
            d="M0,120 Q200,120 400,120 T800,120 T1200,120 T1600,120 T2000,120 L2000,200 L0,200 Z"
            fill="rgba(37, 99, 235, 0.4)"
            className="drop-shadow-md" data-id="qn2ordcib" data-path="src/components/WaterWaveBackground.tsx" />

          
          {/* Wave 1 - Front layer with interactive distortion */}
          <path
            ref={wave1Ref}
            d="M0,100 Q150,100 300,100 T600,100 T900,100 T1200,100 T1500,100 T1800,100 L1800,200 L0,200 Z"
            fill="rgba(59, 130, 246, 0.6)"
            className="drop-shadow-lg"
            style={{
              filter: `drop-shadow(0 4px 8px rgba(59, 130, 246, 0.3)) brightness(${1 + (mousePosition.y - 50) * 0.002})`
            }} data-id="1ynykmoxh" data-path="src/components/WaterWaveBackground.tsx" />


          {/* Interactive ocean line effects */}
          <path
            d="M0,90 Q150,95 300,90 T600,90 T900,90 T1200,90 T1500,90 T1800,90"
            fill="none"
            stroke="rgba(147, 197, 253, 0.8)"
            strokeWidth="2"
            className="ocean-line"
            style={{
              filter: 'blur(1px)',
              opacity: 0.6 + mousePosition.y / 100 * 0.4
            }} data-id="uoz0nitwv" data-path="src/components/WaterWaveBackground.tsx" />

          
          <path
            d="M0,110 Q200,115 400,110 T800,110 T1200,110 T1600,110"
            fill="none"
            stroke="rgba(59, 130, 246, 0.6)"
            strokeWidth="1.5"
            className="ocean-line"
            style={{
              filter: 'blur(0.5px)',
              opacity: 0.4 + mousePosition.x / 100 * 0.3
            }} data-id="qpa1m10um" data-path="src/components/WaterWaveBackground.tsx" />


          <path
            d="M0,130 Q250,135 500,130 T1000,130 T1500,130"
            fill="none"
            stroke="rgba(29, 78, 216, 0.5)"
            strokeWidth="1"
            className="ocean-line"
            style={{
              filter: 'blur(0.3px)',
              opacity: 0.3 + mousePosition.y / 100 * 0.2
            }} data-id="87h2z62nm" data-path="src/components/WaterWaveBackground.tsx" />

        </svg>
      </div>

      {/* Enhanced bubbles effect with cursor interaction */}
      <div className="absolute inset-0 pointer-events-none" data-id="zfcd3pbci" data-path="src/components/WaterWaveBackground.tsx">
        {[...Array(25)].map((_, i) =>
        <div
          key={i}
          className="absolute rounded-full opacity-30"
          style={{
            width: `${Math.random() * 8 + 4}px`,
            height: `${Math.random() * 8 + 4}px`,
            left: `${Math.random() * 100}%`,
            top: `${Math.random() * 100}%`,
            background: `radial-gradient(circle, 
                rgba(255, 255, 255, 0.8) 0%, 
                rgba(147, 197, 253, 0.6) 50%, 
                transparent 100%)`,
            animationDelay: `${Math.random() * 5}s`,
            animation: `enhanced-bubble-float ${4 + Math.random() * 6}s infinite linear`,
            transform: `translate(${(mousePosition.x - 50) * 0.2}px, ${(mousePosition.y - 50) * 0.2}px)`,
            boxShadow: '0 2px 8px rgba(59, 130, 246, 0.3)'
          }} data-id="93931z5hs" data-path="src/components/WaterWaveBackground.tsx" />

        )}
      </div>

      {/* Light rays effect */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20"
        style={{
          background: `linear-gradient(${45 + (mousePosition.x - 50) * 0.5}deg, 
            transparent 0%, 
            rgba(147, 197, 253, 0.3) 20%, 
            transparent 40%, 
            rgba(59, 130, 246, 0.2) 60%, 
            transparent 80%)`
        }} data-id="8p3lklo9i" data-path="src/components/WaterWaveBackground.tsx" />


      {/* Content */}
      <div className="relative z-10" data-id="eigs4gvkt" data-path="src/components/WaterWaveBackground.tsx">
        {children}
      </div>

      <style jsx data-id="abp7mmyl7" data-path="src/components/WaterWaveBackground.tsx">{`
        @keyframes enhanced-bubble-float {
          0% {
            transform: translateY(100vh) scale(0) rotate(0deg);
            opacity: 0;
          }
          10% {
            opacity: 0.4;
          }
          50% {
            transform: translateY(50vh) scale(1) rotate(180deg);
            opacity: 0.6;
          }
          90% {
            opacity: 0.3;
          }
          100% {
            transform: translateY(-20px) scale(0.3) rotate(360deg);
            opacity: 0;
          }
        }

        .ocean-line {
          animation: ocean-pulse 3s ease-in-out infinite;
        }

        @keyframes ocean-pulse {
          0%, 100% { 
            stroke-width: 1;
            opacity: 0.4;
          }
          50% { 
            stroke-width: 2;
            opacity: 0.8;
          }
        }
      `}</style>
    </div>);

};

export default WaterWaveBackground;