import React from 'react';
import { motion } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import {
  Mail,
  Phone,
  MapPin,
  Facebook,
  Twitter,
  Instagram,
  Linkedin,
  Youtube,
  Send,
  Heart,
  Shield,
  Award,
  Clock } from
'lucide-react';

const Footer: React.FC = () => {
  const footerLinks = {
    products: {
      title: 'Medical Products',
      links: [
      'Diagnostic Equipment',
      'Monitoring Devices',
      'Surgical Instruments',
      'Emergency Supplies',
      'Safety Equipment',
      'Digital Health']

    },
    company: {
      title: 'Company',
      links: [
      'About MedCart',
      'Our Mission',
      'Careers',
      'Press Center',
      'Investor Relations',
      'Contact Us']

    },
    support: {
      title: 'Support',
      links: [
      'Help Center',
      'Technical Support',
      'Product Manuals',
      'Warranty Info',
      'Return Policy',
      'Live Chat']

    },
    resources: {
      title: 'Resources',
      links: [
      'Healthcare Blog',
      'Product Guides',
      'Case Studies',
      'Webinars',
      'Training Materials',
      'API Documentation']

    }
  };

  const socialLinks = [
  { icon: Facebook, href: '#', label: 'Facebook' },
  { icon: Twitter, href: '#', label: 'Twitter' },
  { icon: Instagram, href: '#', label: 'Instagram' },
  { icon: Linkedin, href: '#', label: 'LinkedIn' },
  { icon: Youtube, href: '#', label: 'YouTube' }];


  const trustBadges = [
  { icon: Shield, text: 'FDA Approved' },
  { icon: Award, text: 'ISO Certified' },
  { icon: Heart, text: 'Healthcare First' },
  { icon: Clock, text: '24/7 Support' }];


  return (
    <footer className="bg-black border-t border-gray-800" data-id="5nhfvlt1i" data-path="src/components/Footer.tsx">
      {/* Newsletter Section */}
      <div className="border-b border-gray-800" data-id="fj0ika9we" data-path="src/components/Footer.tsx">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12" data-id="a7de7jufl" data-path="src/components/Footer.tsx">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="text-center" data-id="k9mf1wv2r" data-path="src/components/Footer.tsx">

            <h3 className="text-2xl md:text-3xl font-bold text-white mb-4" data-id="9t38fzrlw" data-path="src/components/Footer.tsx">
              Stay Updated with Healthcare Innovation
            </h3>
            <p className="text-gray-400 mb-8 max-w-2xl mx-auto" data-id="973ri1i5l" data-path="src/components/Footer.tsx">
              Get the latest updates on medical products, industry insights, and exclusive offers 
              delivered straight to your inbox.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto" data-id="7wn4x1ji1" data-path="src/components/Footer.tsx">
              <Input
                type="email"
                placeholder="Enter your email address"
                className="bg-gray-800 border-gray-700 text-white placeholder-gray-400 focus:border-emerald-400" data-id="xzz5ttetb" data-path="src/components/Footer.tsx" />

              <Button className="bg-emerald-500 hover:bg-emerald-600 text-white px-8" data-id="raraqgi0d" data-path="src/components/Footer.tsx">
                <Send className="h-4 w-4 mr-2" data-id="bzui7o8gd" data-path="src/components/Footer.tsx" />
                Subscribe
              </Button>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Main Footer Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16" data-id="sxux294rk" data-path="src/components/Footer.tsx">
        <div className="grid grid-cols-1 lg:grid-cols-6 gap-8" data-id="h6nkokhhc" data-path="src/components/Footer.tsx">
          {/* Brand Section */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-2" data-id="c6zpgnx3i" data-path="src/components/Footer.tsx">

            <div className="flex items-center space-x-2 mb-6" data-id="srg0ppub5" data-path="src/components/Footer.tsx">
              <div className="w-10 h-10 bg-gradient-to-r from-emerald-400 to-teal-400 rounded-lg flex items-center justify-center" data-id="69k2uhl7h" data-path="src/components/Footer.tsx">
                <span className="text-black font-bold text-lg" data-id="h5p3tqp5g" data-path="src/components/Footer.tsx">M</span>
              </div>
              <span className="text-2xl font-bold text-white" data-id="pq7wuuv9e" data-path="src/components/Footer.tsx">MEDCART</span>
            </div>
            
            <p className="text-gray-400 mb-6 leading-relaxed" data-id="p3bzbqnrj" data-path="src/components/Footer.tsx">
              Leading provider of premium medical equipment and healthcare solutions. 
              Trusted by healthcare professionals worldwide for quality, reliability, and innovation.
            </p>
            
            <div className="space-y-3" data-id="7eb3wp5xu" data-path="src/components/Footer.tsx">
              <div className="flex items-center text-gray-400" data-id="73clski2q" data-path="src/components/Footer.tsx">
                <Phone className="h-4 w-4 mr-3 text-emerald-400" data-id="nlloevzmc" data-path="src/components/Footer.tsx" />
                <span data-id="rlx0i11ue" data-path="src/components/Footer.tsx">+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center text-gray-400" data-id="hrgtr194w" data-path="src/components/Footer.tsx">
                <Mail className="h-4 w-4 mr-3 text-emerald-400" data-id="incbkhcu6" data-path="src/components/Footer.tsx" />
                <span data-id="a7ccp0wxu" data-path="src/components/Footer.tsx">support@medcart.com</span>
              </div>
              <div className="flex items-center text-gray-400" data-id="lhiabp024" data-path="src/components/Footer.tsx">
                <MapPin className="h-4 w-4 mr-3 text-emerald-400" data-id="5u640836f" data-path="src/components/Footer.tsx" />
                <span data-id="e8kdljft7" data-path="src/components/Footer.tsx">123 Medical Plaza, Healthcare District, NY 10001</span>
              </div>
            </div>
          </motion.div>

          {/* Links Sections */}
          {Object.entries(footerLinks).map(([key, section], index) =>
          <motion.div
            key={key}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 * (index + 1) }} data-id="s42na9yo2" data-path="src/components/Footer.tsx">

              <h4 className="text-white font-semibold mb-4" data-id="nqznrsgrh" data-path="src/components/Footer.tsx">{section.title}</h4>
              <ul className="space-y-2" data-id="k0a085vqi" data-path="src/components/Footer.tsx">
                {section.links.map((link, linkIndex) =>
              <li key={linkIndex} data-id="u21ruo9qy" data-path="src/components/Footer.tsx">
                    <a
                  href="#"
                  className="text-gray-400 hover:text-emerald-400 transition-colors duration-200 text-sm" data-id="hsr1mt2p2" data-path="src/components/Footer.tsx">

                      {link}
                    </a>
                  </li>
              )}
              </ul>
            </motion.div>
          )}
        </div>

        {/* Trust Badges */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-12 pt-8 border-t border-gray-800" data-id="cwg532ko8" data-path="src/components/Footer.tsx">

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4" data-id="15dyqe1aw" data-path="src/components/Footer.tsx">
            {trustBadges.map((badge, index) =>
            <div
              key={index}
              className="flex items-center justify-center space-x-2 bg-gray-800/50 rounded-lg p-4 border border-gray-700" data-id="dekge64ad" data-path="src/components/Footer.tsx">

                <badge.icon className="h-5 w-5 text-emerald-400" data-id="6huvj4dqs" data-path="src/components/Footer.tsx" />
                <span className="text-sm text-gray-300 font-medium" data-id="rgvzfbicw" data-path="src/components/Footer.tsx">{badge.text}</span>
              </div>
            )}
          </div>
        </motion.div>
      </div>

      <Separator className="bg-gray-800" data-id="zz7bg77qy" data-path="src/components/Footer.tsx" />

      {/* Bottom Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8" data-id="0wukgni2h" data-path="src/components/Footer.tsx">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0" data-id="ssquoko7t" data-path="src/components/Footer.tsx">
          <div className="text-gray-400 text-sm" data-id="bmas5q6ef" data-path="src/components/Footer.tsx">
            © 2024 MedCart. All rights reserved. | Privacy Policy | Terms of Service | Cookie Policy
          </div>
          
          <div className="flex items-center space-x-4" data-id="vnwbpxvyc" data-path="src/components/Footer.tsx">
            <span className="text-gray-500 text-sm" data-id="c43xupiao" data-path="src/components/Footer.tsx">Follow us:</span>
            {socialLinks.map((social, index) =>
            <motion.a
              key={index}
              href={social.href}
              aria-label={social.label}
              whileHover={{ scale: 1.1, y: -2 }}
              transition={{ type: "spring", stiffness: 300 }}
              className="text-gray-400 hover:text-emerald-400 transition-colors duration-200" data-id="lfxil9cz8" data-path="src/components/Footer.tsx">

                <social.icon className="h-5 w-5" data-id="ez6bnnpf9" data-path="src/components/Footer.tsx" />
              </motion.a>
            )}
          </div>
        </div>

        {/* Made with Love */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.8 }}
          className="text-center mt-8 pt-8 border-t border-gray-800" data-id="xrcipkz3d" data-path="src/components/Footer.tsx">

          <div className="flex items-center justify-center text-gray-500 text-sm" data-id="5u1xdqshu" data-path="src/components/Footer.tsx">
            <span data-id="4h9rw1ytx" data-path="src/components/Footer.tsx">Made with</span>
            <motion.div
              animate={{
                scale: [1, 1.2, 1],
                color: ['#ef4444', '#f97316', '#ef4444']
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                repeatType: "reverse"
              }}
              className="mx-2" data-id="76j0pan0q" data-path="src/components/Footer.tsx">

              <Heart className="h-4 w-4 fill-current" data-id="29ptan9qa" data-path="src/components/Footer.tsx" />
            </motion.div>
            <span data-id="dvqpc5y48" data-path="src/components/Footer.tsx">for healthcare professionals worldwide</span>
          </div>
        </motion.div>
      </div>
    </footer>);

};

export default Footer;