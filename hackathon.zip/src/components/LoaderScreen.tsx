import React from 'react';
import { motion } from 'framer-motion';

const LoaderScreen: React.FC = () => {
  const letters = "MEDCART".split("");

  return (
    <motion.div
      className="fixed inset-0 bg-black flex items-center justify-center z-50"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.5 }} data-id="8ia1ncr0c" data-path="src/components/LoaderScreen.tsx">

      <div className="flex flex-col items-center space-y-8" data-id="1ktkqxg1k" data-path="src/components/LoaderScreen.tsx">
        <div className="flex space-x-2" data-id="4h61td2im" data-path="src/components/LoaderScreen.tsx">
          {letters.map((letter, index) =>
          <motion.span
            key={index}
            className="text-4xl md:text-6xl font-bold text-emerald-400"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{
              duration: 0.6,
              delay: index * 0.1,
              ease: "easeOut"
            }} data-id="aunc3avvk" data-path="src/components/LoaderScreen.tsx">

              {letter}
            </motion.span>
          )}
        </div>
        
        <motion.div
          className="flex space-x-1"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }} data-id="19w9cxvjo" data-path="src/components/LoaderScreen.tsx">

          {[...Array(3)].map((_, i) =>
          <motion.div
            key={i}
            className="w-2 h-2 bg-emerald-400 rounded-full"
            animate={{
              scale: [1, 1.5, 1],
              opacity: [0.5, 1, 0.5]
            }}
            transition={{
              duration: 1,
              repeat: Infinity,
              delay: i * 0.2
            }} data-id="fctkpg9hc" data-path="src/components/LoaderScreen.tsx" />

          )}
        </motion.div>
        
        <motion.p
          className="text-gray-400 text-sm tracking-wider"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1.5 }} data-id="4k0b6thg1" data-path="src/components/LoaderScreen.tsx">

          LOADING PREMIUM HEALTHCARE EXPERIENCE
        </motion.p>
      </div>
    </motion.div>);

};

export default LoaderScreen;