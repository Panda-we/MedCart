import React, { useRef, useState } from 'react';
import { motion, useMotionValue, useSpring, useTransform } from 'framer-motion';

interface TiltCardProps {
  children: React.ReactNode;
  className?: string;
  maxTilt?: number;
  perspective?: number;
  scale?: number;
  speed?: number;
}

const TiltCard: React.FC<TiltCardProps> = ({
  children,
  className = '',
  maxTilt = 15,
  perspective = 1000,
  scale = 1.05,
  speed = 400
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [isHovered, setIsHovered] = useState(false);

  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);

  const rotateX = useSpring(
    useTransform(mouseY, [-0.5, 0.5], [maxTilt, -maxTilt]),
    { stiffness: speed, damping: 30 }
  );

  const rotateY = useSpring(
    useTransform(mouseX, [-0.5, 0.5], [-maxTilt, maxTilt]),
    { stiffness: speed, damping: 30 }
  );

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;

    const rect = cardRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const mouseXPercent = (e.clientX - centerX) / (rect.width / 2);
    const mouseYPercent = (e.clientY - centerY) / (rect.height / 2);

    mouseX.set(mouseXPercent);
    mouseY.set(mouseYPercent);
  };

  const handleMouseLeave = () => {
    mouseX.set(0);
    mouseY.set(0);
    setIsHovered(false);
  };

  const handleMouseEnter = () => {
    setIsHovered(true);
  };

  return (
    <motion.div
      ref={cardRef}
      className={`transform-gpu ${className}`}
      style={{
        perspective: perspective,
        transformStyle: 'preserve-3d'
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onMouseEnter={handleMouseEnter}
      animate={{
        scale: isHovered ? scale : 1
      }}
      transition={{
        duration: 0.3,
        ease: 'easeOut'
      }} data-id="ydxx1ft56" data-path="src/components/TiltCard.tsx">

      <motion.div
        className="w-full h-full relative"
        style={{
          rotateX,
          rotateY,
          transformStyle: 'preserve-3d'
        }} data-id="qssqpdn5n" data-path="src/components/TiltCard.tsx">

        {children}
        
        {/* Shine Effect */}
        <motion.div
          className="absolute inset-0 pointer-events-none rounded-lg"
          style={{
            background: `linear-gradient(135deg, 
              rgba(255,255,255,0) 0%, 
              rgba(255,255,255,${isHovered ? 0.1 : 0}) 50%, 
              rgba(255,255,255,0) 100%)`,
            transform: `translateX(${mouseX.get() * 100}px) translateY(${mouseY.get() * 100}px)`
          }} data-id="z2fxos33e" data-path="src/components/TiltCard.tsx" />

      </motion.div>
    </motion.div>);

};

export default TiltCard;