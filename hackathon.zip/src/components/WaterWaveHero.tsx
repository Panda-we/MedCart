import React from 'react';
import { motion } from 'framer-motion';
import WaterWaveBackground from './WaterWaveBackground';
import { Button } from '@/components/ui/button';

const WaterWaveHero: React.FC = () => {
  return (
    <WaterWaveBackground className="min-h-screen flex items-center justify-center" data-id="0ub0r124n" data-path="src/components/WaterWaveHero.tsx">
      <div className="container mx-auto px-4 text-center" data-id="g5olb7q9s" data-path="src/components/WaterWaveHero.tsx">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-4xl mx-auto" data-id="lgu329u56" data-path="src/components/WaterWaveHero.tsx">

          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 drop-shadow-lg" data-id="qzu30yooe" data-path="src/components/WaterWaveHero.tsx">
            Dive Into The
            <span className="block bg-gradient-to-r from-cyan-200 to-blue-200 bg-clip-text text-transparent" data-id="iw9uatph3" data-path="src/components/WaterWaveHero.tsx">
              Ocean of Possibilities
            </span>
          </h1>
          
          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.3 }}
            className="text-xl md:text-2xl text-blue-100 mb-8 max-w-2xl mx-auto leading-relaxed" data-id="0srihq7hp" data-path="src/components/WaterWaveHero.tsx">

            Experience the beauty of fluid motion and immersive design. 
            Let the waves carry your imagination to new depths.
          </motion.p>
          
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center" data-id="76f3vle4h" data-path="src/components/WaterWaveHero.tsx">

            <Button
              size="lg"
              className="bg-white text-blue-600 hover:bg-blue-50 shadow-lg hover:shadow-xl transition-all duration-300 px-8 py-3 text-lg font-semibold" data-id="c2uppqcj6" data-path="src/components/WaterWaveHero.tsx">

              Explore the Depths
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-blue-600 shadow-lg hover:shadow-xl transition-all duration-300 px-8 py-3 text-lg font-semibold" data-id="z11g81hx3" data-path="src/components/WaterWaveHero.tsx">

              Learn More
            </Button>
          </motion.div>
        </motion.div>
        
        {/* Floating elements */}
        <motion.div
          animate={{
            y: [0, -20, 0],
            rotate: [0, 5, 0]
          }}
          transition={{
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }}
          className="absolute bottom-20 left-10 w-20 h-20 opacity-40" data-id="e8zllvxzs" data-path="src/components/WaterWaveHero.tsx">

          <img
            src="https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=200&h=200&fit=crop&crop=center"
            alt="Jellyfish"
            className="w-full h-full rounded-full object-cover shadow-lg" data-id="2sjqhian3" data-path="src/components/WaterWaveHero.tsx" />

        </motion.div>
        
        <motion.div
          animate={{
            y: [0, -15, 0],
            rotate: [0, -3, 0]
          }}
          transition={{
            duration: 5,
            repeat: Infinity,
            ease: "easeInOut",
            delay: 1
          }}
          className="absolute bottom-32 right-16 w-16 h-16 opacity-50" data-id="w91sgdjcp" data-path="src/components/WaterWaveHero.tsx">

          <img
            src="https://images.unsplash.com/photo-1583212292454-1fe6229603b7?w=200&h=200&fit=crop&crop=center"
            alt="Sea turtle"
            className="w-full h-full rounded-full object-cover shadow-lg" data-id="zrn2sdpw4" data-path="src/components/WaterWaveHero.tsx" />

        </motion.div>
      </div>
    </WaterWaveBackground>);

};

export default WaterWaveHero;